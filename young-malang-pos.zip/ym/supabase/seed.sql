-- =====================================================================
-- THE YOUNG MALANG — seed data (run AFTER schema.sql)
-- Prices are SAMPLE prices — change them from the Admin panel (admin.html).
-- Safe to re-run: menu is only inserted when the menu is empty.
-- =====================================================================

insert into public.settings (key, value) values
 ('restaurant', '{"name":"THE YOUNG MALANG","tagline":"Pizza & Burger","phones":["0349-8190030","0337-1111475"],"address":"Near Rajput Marriage Hall, Sardar Market","ntn":"","receipt_footer":"Thank you for visiting The Young Malang!"}'),
 ('charges', '{"delivery_fee":150,"free_delivery_above":0,"tax_pct":0,"service_charge_pct":0,"min_online_order":0}'),
 ('payment_methods', '["Cash","Card","Online Payment","Easypaisa","JazzCash"]'),
 ('permissions', '{"cashier_max_discount_pct":10,"cashier_can_cancel":false}'),
 ('kitchen', '{"sound":true}'),
 ('online', '{"accepting_orders":true}'),
 ('rider', '{"default_rate":100}')
on conflict (key) do nothing;

insert into public.dining_tables (code, seats)
select 'T' || lpad(g::text, 2, '0'), case when g <= 4 then 4 else 6 end
from generate_series(1, 8) g
on conflict (code) do nothing;

insert into public.rider_incentives (name, period, target, bonus)
select * from (values
  ('100 rides this month',  'month', 100, 2000),
  ('200 rides this month',  'month', 200, 5000),
  ('300 rides this month',  'month', 300, 8000),
  ('15 deliveries in a day','day',    15,  500)
) v(name, period, target, bonus)
where not exists (select 1 from public.rider_incentives);

do $$
declare c_pizza int; c_burger int; c_fries int; c_snack int; c_drink int; c_deal int; c_dessert int; pid int;
begin
  if exists (select 1 from public.categories) then return; end if;

  insert into public.categories (name, name_ur, sort) values ('Pizza', 'پیزا', 1) returning id into c_pizza;
  insert into public.categories (name, name_ur, sort) values ('Burgers', 'برگر', 2) returning id into c_burger;
  insert into public.categories (name, name_ur, sort) values ('Fries', 'فرائز', 3) returning id into c_fries;
  insert into public.categories (name, name_ur, sort) values ('Snacks', 'اسنیکس', 4) returning id into c_snack;
  insert into public.categories (name, name_ur, sort) values ('Drinks', 'مشروبات', 5) returning id into c_drink;
  insert into public.categories (name, name_ur, sort) values ('Deals', 'ڈیلز', 6) returning id into c_deal;
  insert into public.categories (name, name_ur, sort) values ('Desserts', 'میٹھا', 7) returning id into c_dessert;

  -- Pizzas (sizes)
  insert into public.products (category_id, name, name_ur, price, sort) values (c_pizza, 'Chicken Tikka Pizza', 'چکن تکہ پیزا', 0, 1) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Small','چھوٹا',550,1),(pid,'Medium','درمیانہ',750,2),(pid,'Large','بڑا',950,3);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_pizza, 'Fajita Pizza', 'فاجیتا پیزا', 0, 2) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Small','چھوٹا',550,1),(pid,'Medium','درمیانہ',750,2),(pid,'Large','بڑا',950,3);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_pizza, 'Cheese Lover Pizza', 'چیز لور پیزا', 0, 3) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Small','چھوٹا',600,1),(pid,'Medium','درمیانہ',800,2),(pid,'Large','بڑا',1000,3);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_pizza, 'Pepperoni Pizza', 'پیپرونی پیزا', 0, 4) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Small','چھوٹا',650,1),(pid,'Medium','درمیانہ',850,2),(pid,'Large','بڑا',1050,3);

  -- Burgers
  insert into public.products (category_id, name, name_ur, price, sort) values (c_burger, 'Zinger Burger', 'زنگر برگر', 0, 1) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Regular','عام',550,1),(pid,'Large','بڑا',750,2);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_burger, 'Beef Burger', 'بیف برگر', 0, 2) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Regular','عام',600,1),(pid,'Large','بڑا',800,2);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_burger, 'Chicken Burger', 'چکن برگر', 0, 3) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Regular','عام',400,1),(pid,'Large','بڑا',550,2);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_burger, 'Double Patty Burger', 'ڈبل پیٹی برگر', 850, 4);

  -- Fries / snacks
  insert into public.products (category_id, name, name_ur, price, sort) values (c_fries, 'French Fries', 'فرنچ فرائز', 0, 1) returning id into pid;
  insert into public.product_variants (product_id, name, name_ur, price, sort) values (pid,'Regular','عام',200,1),(pid,'Large','بڑا',320,2);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_fries, 'Masala Fries', 'مصالحہ فرائز', 250, 2);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_snack, 'Chicken Nuggets (6 pcs)', 'چکن نگٹس (6)', 380, 1);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_snack, 'Hot Wings (6 pcs)', 'ہاٹ ونگز (6)', 420, 2);

  -- Drinks
  insert into public.products (category_id, name, name_ur, price, sort) values (c_drink, 'Soft Drink (345ml)', 'سافٹ ڈرنک', 150, 1);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_drink, 'Mint Margarita', 'منٹ مارگریٹا', 250, 2);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_drink, 'Mineral Water', 'منرل واٹر', 80, 3);

  -- Deals
  insert into public.products (category_id, name, name_ur, price, description, sort) values (c_deal, 'Deal 1: Burger + Fries + Drink', 'ڈیل 1', 850, 'Zinger burger, regular fries, soft drink', 1);
  insert into public.products (category_id, name, name_ur, price, description, sort) values (c_deal, 'Deal 2: Large Pizza + 2 Drinks', 'ڈیل 2', 1150, 'Any large pizza with 2 soft drinks', 2);

  -- Desserts
  insert into public.products (category_id, name, name_ur, price, sort) values (c_dessert, 'Chocolate Brownie', 'چاکلیٹ براؤنی', 300, 1);
  insert into public.products (category_id, name, name_ur, price, sort) values (c_dessert, 'Ice Cream Cup', 'آئس کریم کپ', 200, 2);

  -- Add-ons
  insert into public.addons (category_id, name, name_ur, price) values
    (c_burger, 'Extra Cheese', 'اضافی چیز', 100), (c_burger, 'Extra Chicken', 'اضافی چکن', 150), (c_burger, 'Extra Sauce', 'اضافی ساس', 50),
    (c_pizza,  'Extra Cheese', 'اضافی چیز', 150), (c_pizza,  'Extra Toppings', 'اضافی ٹاپنگ', 200), (c_pizza, 'Extra Sauce', 'اضافی ساس', 50),
    (c_fries,  'Cheese Dip', 'چیز ڈپ', 80), (c_snack, 'Extra Sauce', 'اضافی ساس', 50);
end $$;
