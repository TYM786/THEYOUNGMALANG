/* =====================================================================
   THE YOUNG MALANG — customer ordering site (order.html)
   Public page: no login. Uses place_online_order / track_order RPCs.
   ===================================================================== */
const OS = { cats: [], products: [], variants: [], addons: [], settings: {}, cart: [], cat: null, tableCode: null, ref: uuid() };
const CART_KEY = 'ym_site_cart_v1';

async function boot() {
  setTheme(localStorage.getItem('ym_theme') || 'classic'); setLang(LANG);
  const params = new URLSearchParams(location.search);
  OS.tableCode = params.get('table');
  try { const saved = JSON.parse(localStorage.getItem(CART_KEY) || '[]'); if (Array.isArray(saved)) OS.cart = saved; } catch (e) { /* ignore */ }
  $('#modal-root') || document.body.insertAdjacentHTML('beforeend', '<div id="modal-root"></div><div id="toast-root"></div>');
  drawShell();
  if (!CONFIGURED) { $('#site-main').innerHTML = `<div class="empty">Supabase is not connected yet. Edit js/config.js.</div>`; return; }
  const [cats, prods, vars, adds, settings] = await Promise.all([
    q(sb.from('categories').select('*').eq('is_active', true).order('sort')),
    q(sb.from('products').select('*').eq('is_active', true).order('sort')),
    q(sb.from('product_variants').select('*')),
    q(sb.from('addons').select('*').eq('is_active', true)),
    loadSettings()
  ]);
  Object.assign(OS, { cats, products: prods, variants: vars, addons: adds, settings });
  OS.cat = cats[0] && cats[0].id;
  paintCats(); paintProds(); paintCart();
  sb.channel('site-products').on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, async () => {
    OS.products = await q(sb.from('products').select('*').eq('is_active', true).order('sort')); paintProds();
  }).subscribe();
}

function drawShell() {
  document.body.innerHTML = `
    <header class="site-head">${logoHTML(56)}<div class="grow"><b>${esc(BR.name)}</b><div class="sm muted">${esc(BR.tagline)} · ${esc(BR.address)}</div></div>
      <button class="btn ghost sm lang-btn" id="site-lang"></button>${themeSelect('site-theme')}<button class="btn sm ghost" id="site-track">📦 ${t('Track Order')}</button></header>
    <div class="site-hero"><h1 data-t="Order Online">Order Online</h1><p class="muted">${BR.phones.join(' · ')}</p></div>
    ${OS.tableCode ? `<div class="site-wrap" style="padding-bottom:8px"><div class="banner">🍽️ ${t('Table Order')} — ${t("You're ordering for table")} <b>${esc(OS.tableCode.toUpperCase())}</b></div></div>` : ''}
    <div class="site-wrap">
      <div>
        <div class="site-cats" id="site-cats"></div>
        <div class="prod-grid" id="site-prods"></div>
      </div>
      <aside class="cart-side" id="site-cart"></aside>
    </div>
    <button class="btn primary lg fab" id="site-fab">🛒 ${t('View Order')}</button>
    <div id="modal-root"></div><div id="toast-root"></div>`;
  $('#site-lang').onclick = () => { setLang(LANG === 'ur' ? 'en' : 'ur'); drawShell(); paintCats(); paintProds(); paintCart(); };
  $('#site-theme').onchange = e => setTheme(e.target.value);
  $('#site-track').onclick = trackModal;
  $('#site-fab').onclick = () => document.body.classList.add('cart-open');
}

function paintCats() {
  $('#site-cats').innerHTML = OS.cats.map(c => `<button class="chip ${c.id === OS.cat ? 'on' : ''}" data-c="${c.id}">${catEmoji(c.name)} ${esc(pick(c))}</button>`).join('');
  $$('#site-cats .chip').forEach(b => b.onclick = () => { OS.cat = +b.dataset.c; paintCats(); paintProds(); });
}
function paintProds() {
  const list = OS.products.filter(p => p.category_id === OS.cat);
  $('#site-prods').innerHTML = list.map(p => `<button type="button" class="pcard ${p.is_available ? '' : 'off'}" data-p="${p.id}">
    ${p.image_url ? `<img src="${esc(p.image_url)}" alt="">` : `<div class="ph">${catEmoji((OS.cats.find(c => c.id === p.category_id) || {}).name)}</div>`}
    <div class="pi"><div class="pn">${esc(pick(p))}</div>${p.description ? `<div class="sm muted">${esc(p.description)}</div>` : ''}<div class="pp">${money(p.price) === money(0) ? t('From') + ' ' + money(Math.min(...OS.variants.filter(v => v.product_id === p.id).map(v => v.price), Infinity)) : money(p.price)}</div>${!p.is_available ? `<span class="pill bad sm">${t('Unavailable')}</span>` : ''}</div></button>`).join('') || `<div class="empty">${t('No products')}</div>`;
  $$('#site-prods .pcard:not(.off)').forEach(b => b.onclick = () => {
    const p = OS.products.find(x => x.id === +b.dataset.p);
    openItemPicker({ product: p, variants: OS.variants, addons: OS.addons, onAdd: it => { OS.cart.push(it); persist(); paintCart(); toast(`${t('Added')}: ${pick(p)}`); } });
  });
}
function persist() { localStorage.setItem(CART_KEY, JSON.stringify(OS.cart)); }
function siteCalc() {
  const sub = OS.cart.reduce((s, i) => s + (i.base + i.addons.reduce((a, x) => a + x.price, 0)) * i.qty, 0);
  const chg = OS.settings.charges || {};
  const ful = OS.tableCode ? 'dinein' : ($('#site-ful') ? $('#site-ful').value : 'delivery');
  let delivery = 0;
  if (!OS.tableCode && ful === 'delivery') { delivery = num(chg.delivery_fee); if (num(chg.free_delivery_above) > 0 && sub >= num(chg.free_delivery_above)) delivery = 0; }
  const tax = Math.round(sub * num(chg.tax_pct) / 100);
  return { sub, delivery, tax, total: sub + delivery + tax, ful };
}
function paintCart() {
  const calc = siteCalc();
  const box = $('#site-cart'); if (!box) return;
  box.innerHTML = `<div class="card">
    <div class="row between"><h3>${t('Your Cart')}</h3><button class="icon-btn only-mobile" data-close-cart>✕</button></div>
    ${!OS.tableCode ? `<select id="site-ful" class="mb">${['delivery', 'pickup'].map(f => `<option value="${f}">${t(FUL[f])}</option>`).join('')}</select>` : ''}
    <div id="site-lines">${OS.cart.length ? OS.cart.map((i, idx) => `<div class="line">
      <span class="ln">${esc(pick({ name: i.name, name_ur: i.name_ur }))}${i.variant_name ? ` · ${esc(i.variant_name)}` : ''}</span><span class="lp">${money((i.base + i.addons.reduce((a, x) => a + x.price, 0)) * i.qty)}</span>
      ${i.addons.length ? `<span class="lm">+ ${i.addons.map(a => esc(a.name)).join(', ')}</span>` : ''}
      <span class="lc"><span class="qty"><button data-q="-1" data-i="${idx}">−</button><span>${i.qty}</span><button data-q="1" data-i="${idx}">+</button></span><button class="icon-btn" data-rm="${idx}">🗑</button></span></div>`).join('') : `<div class="empty">${t('Your cart is empty')}</div>`}</div>
    ${OS.cart.length ? `<div class="tot-row"><span>${t('Subtotal')}</span><span>${money(calc.sub)}</span></div>
    ${calc.delivery ? `<div class="tot-row"><span>${t('Delivery')}</span><span>${money(calc.delivery)}</span></div>` : ''}
    ${calc.tax ? `<div class="tot-row"><span>${t('Tax')}</span><span>${money(calc.tax)}</span></div>` : ''}
    <div class="tot-row grand"><span>${t('TOTAL')}</span><span>${money(calc.total)}</span></div>
    <button class="btn primary lg block mt" id="site-checkout">${t('Place Order')}</button>` : ''}
    </div>`;
  const ful = $('#site-ful'); if (ful) ful.onchange = paintCart;
  $$('#site-lines [data-q]').forEach(b => b.onclick = () => { OS.cart[+b.dataset.i].qty = Math.max(1, OS.cart[+b.dataset.i].qty + +b.dataset.q); persist(); paintCart(); });
  $$('#site-lines [data-rm]').forEach(b => b.onclick = () => { OS.cart.splice(+b.dataset.rm, 1); persist(); paintCart(); });
  const cc = $('[data-close-cart]', box); if (cc) cc.onclick = () => document.body.classList.remove('cart-open');
  const co = $('#site-checkout'); if (co) co.onclick = () => checkoutModal(siteCalc());
}

function checkoutModal(calc) {
  const needAddr = !OS.tableCode && calc.ful === 'delivery';
  const w = Modal.open({
    title: t('Your Details'), html: `<div class="form-grid">
    <label class="f">${t('Customer Name')} *<input id="co-name"></label>
    <label class="f">${t('Phone Number')} *<input id="co-phone" inputmode="tel"></label>
    ${needAddr ? `<label class="f full">${t('Address')} *<textarea id="co-addr"></textarea></label>` : ''}
    <label class="f full">${t('Note')}<input id="co-note" placeholder="${t('Anything we should know?')}"></label></div>
    <div class="tot-row grand"><span>${t('TOTAL')}</span><span>${money(calc.total)}</span></div>
    <button class="btn primary lg block" id="co-go">${t('Place Order')}</button>`
  });
  $('#co-go', w).onclick = ev => safe(async () => {
    const name = $('#co-name', w).value.trim(), phone = $('#co-phone', w).value.trim(), addr = $('#co-addr', w) ? $('#co-addr', w).value.trim() : '';
    if (!name) throw new Error(t('Please enter your name'));
    if (!OS.tableCode && !phone) throw new Error(t('Please enter a valid phone number'));
    if (needAddr && !addr) throw new Error(t('Please enter your delivery address'));
    const payload = {
      client_ref: OS.ref, fulfillment: calc.ful, table_code: OS.tableCode || null,
      customer: { name, phone, address: addr }, notes: $('#co-note', w).value.trim() || null,
      items: OS.cart.map(i => ({ product_id: i.product_id, variant_id: i.variant_id, qty: i.qty, addon_ids: i.addons.map(a => a.id), note: i.note }))
    };
    const res = await rpc('place_online_order', payload);
    Modal.close(w); OS.cart = []; persist(); paintCart(); document.body.classList.remove('cart-open');
    OS.ref = uuid();
    Modal.open({
      title: `✅ ${t('Order placed!')}`, html: `<p>${t('We received your order')} — <b>#${esc(res.order_no)}</b></p>
      <p class="sm muted">${phone ? t('Track your order anytime with your order number and phone.') || '' : ''}</p>
      <button class="btn primary lg block" data-close>${t('Continue')}</button>`
    });
  }, { busy: ev.currentTarget });
}

function trackModal() {
  const w = Modal.open({
    title: t('Track Order'), html: `<div class="form-grid">
    <label class="f full">${t('Order #')}<input id="tr-no" placeholder="YM-1234"></label>
    <label class="f full">${t('Phone Number')}<input id="tr-phone"></label></div>
    <button class="btn primary lg" id="tr-go">${t('Track')}</button><div id="tr-res"></div>`
  });
  $('#tr-go', w).onclick = ev => safe(async () => {
    const res = await rpc('track_order', { p_order_no: $('#tr-no', w).value.trim(), p_phone: $('#tr-phone', w).value.trim() });
    $('#tr-res', w).innerHTML = res ? `<div class="card mt"><div class="row"><b class="grow">#${esc(res.order_no)}</b>${stPill(res.status)}</div><div class="sm mt">${t(FUL[res.fulfillment])} · ${money(res.total)}${res.rider ? ' · 🏍️ ' + esc(res.rider) : ''}</div></div>` : `<div class="banner mt">${t('Not found. Check your order number.')}</div>`;
  }, { busy: ev.currentTarget });
}

boot();
