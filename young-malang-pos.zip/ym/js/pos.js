/* =====================================================================
   THE YOUNG MALANG — POS  (part 1: state, navigation, shared actions)
   Loaded after core.js. Views live in pos-order.js and pos-views.js
   ===================================================================== */
const S = { role: '', user: null, settings: {}, cats: [], products: [], variants: [], addons: [], tables: [], riders: [], waiters: [], view: '', cart: null, pending: 0 };
const STAFF = ['super_admin', 'manager', 'cashier'];
const MGR = ['super_admin', 'manager'];
const WSTATUS = { available: 'Available', serving: 'Serving', offline: 'Offline', inactive: 'Inactive' };
const WDOT = { available: 'green', serving: 'orange', offline: 'gray', inactive: 'red' };
const isStaff = () => STAFF.includes(S.role);
const isMgr = () => MGR.includes(S.role);
const OSEL = '*, order_items(*), tbl:dining_tables(code), creator:profiles!created_by(full_name, staff_id), waiter:profiles!waiter_id(full_name, staff_id), deliveries(*, riders(name,rider_code))';
const ACTIVE_D = ['assigned', 'accepted', 'picked_up', 'on_the_way'];
const OPEN_ST = ['pending', 'accepted', 'preparing', 'ready', 'served', 'assigned', 'picked_up', 'on_the_way'];
const DSTATUS = { assigned: 'Assigned', accepted: 'Accepted', picked_up: 'Picked Up', on_the_way: 'On the Way', delivered: 'Delivered', cancelled: 'Cancelled', failed: 'Failed', reassigned: 'Reassigned' };
const isMobile = () => window.matchMedia('(max-width: 900px)').matches;

const NAV = [
  ['dashboard', '📊', 'Dashboard', STAFF],
  ['orders', '🧾', 'Orders', STAFF],
  ['pos', '➕', 'New Order / POS', STAFF],
  ['online', '🌐', 'Online Orders', STAFF],
  ['manual', '✍️', 'Manual Orders', STAFF],
  ['tables', '🍽️', 'Tables', [...STAFF, 'waiter']],
  ['kitchen', '👨‍🍳', 'Kitchen', ['super_admin', 'manager', 'kitchen']],
  ['delivery', '🛵', 'Delivery', STAFF],
  ['riders', '🏍️', 'Riders', STAFF],
  ['payments', '💳', 'Payments', STAFF],
  ['customers', '👥', 'Customers', STAFF],
  ['waiters', '🧑‍🍳', 'Waiters / Staff', MGR],
  ['reports', '📈', 'Reports', MGR],
  ['settings', '⚙️', 'Settings', MGR],
  ['mydeliveries', '🛵', 'My Deliveries', ['delivery']],
  ['mytables', '🍽️', 'My Tables', ['waiter']]
];

/* ---------- boot ---------- */
Shell.init({
  loginTitle: 'POS Login', roles: ['super_admin', 'manager', 'cashier', 'waiter', 'kitchen', 'delivery'], allowSignup: true,
  onReady: async prof => {
    S.role = prof.role; S.user = prof;
    await loadStatic();
    buildSidebar();
    window.addEventListener('hashchange', route);
    Live.start(['orders', 'order_items', 'payments', 'riders', 'deliveries', 'dining_tables', 'products', 'settings', 'profiles'], onLive);
    route(); updateBadge();
  },
  onLang: () => { buildSidebar(); route(true); },
  onLogout: async () => {
    if (S.role === 'delivery' && S.riders[0] && S.riders[0].status === 'available') await sb.rpc('set_rider_status', { p_rider: S.riders[0].id, p_status: 'offline' });
    if (S.role === 'waiter') await sb.rpc('set_waiter_status', { p_user: S.user.id, p_status: 'offline' }).catch(() => {});
  }
});

async function loadStatic() {
  const [cats, prods, vars, adds, tbls, riders, waiters, settings] = await Promise.all([
    q(sb.from('categories').select('*').eq('is_active', true).order('sort')),
    q(sb.from('products').select('*').eq('is_active', true).order('sort')),
    q(sb.from('product_variants').select('*')),
    q(sb.from('addons').select('*').eq('is_active', true)),
    q(sb.from('dining_tables').select('*').order('code')),
    q(sb.from('riders').select('*').order('rider_code')),
    q(sb.from('profiles').select('*').eq('role', 'waiter')),
    loadSettings()
  ]);
  Object.assign(S, { cats, products: prods, variants: vars, addons: adds, tables: tbls, riders, waiters, settings });
}

/* ---------- sidebar / routing ---------- */
function allowedViews() { return NAV.filter(n => n[3].includes(S.role)).map(n => n[0]); }
function buildSidebar() {
  $('#sidebar').innerHTML = `${logoHTML(70)}${NAV.filter(n => n[3].includes(S.role)).map(([id, ic, label]) =>
    `<button class="nav-item ${S.view === id ? 'on' : ''}" data-nav="${id}"><span class="ic">${ic}</span><span>${t(label)}</span>${id === 'online' && S.pending ? `<span class="badge">${S.pending}</span>` : ''}</button>`).join('')}
    <div class="nav-sep"></div><button class="nav-item" data-act="logout"><span class="ic">⎋</span><span>${t('Logout')}</span></button>`;
}
document.addEventListener('click', e => {
  const n = e.target.closest('[data-nav]'); if (n) { location.hash = '#/' + n.dataset.nav; $('#app').classList.remove('menu-open'); }
});
const VIEWS = {};
function route(force) {
  let v = location.hash.replace('#/', '');
  const ok = allowedViews();
  if (!ok.includes(v)) v = S.role === 'kitchen' ? 'kitchen' : S.role === 'delivery' ? 'mydeliveries' : S.role === 'waiter' ? 'mytables' : 'dashboard';
  if (v === S.view && !force) return;
  if (S.view && VIEWS[S.view] && VIEWS[S.view].leave) VIEWS[S.view].leave();
  S.view = v; buildSidebar();
  const label = (NAV.find(n => n[0] === v) || [])[2] || '';
  Shell.title(t(label));
  const vw = $('#view'); vw.className = 'view' + (v === 'pos' || v === 'kitchen' ? ' fill' : ''); vw.innerHTML = '';
  VIEWS[v].render();
}
function refreshView() {
  const v = VIEWS[S.view]; if (!v) return;
  (v.refresh || v.render).call(v);
}
const refreshSoon = debounce(() => { refreshView(); updateBadge(); }, 500);
async function updateBadge() {
  if (!isStaff()) return;
  const { count } = await sb.from('orders').select('id', { count: 'exact', head: true }).eq('status', 'pending');
  if (count !== S.pending) { S.pending = count || 0; buildSidebar(); }
}

/* ---------- realtime ---------- */
const kSeen = new Set();
async function onLive(table, p) {
  if (table === 'orders' && p) {
    const n = p.new || {};
    if (p.eventType === 'INSERT' && isStaff() && isOnlineSrc(n.source) && n.status === 'pending') { beep(); toast(`🌐 ${t('New online order')} #${n.order_no}`); }
    if (['kitchen', 'super_admin', 'manager'].includes(S.role) && n.status === 'accepted' && !kSeen.has(n.id)) {
      kSeen.add(n.id);
      if (S.view === 'kitchen' && (S.settings.kitchen || {}).sound !== false) { beep(); toast(`👨‍🍳 ${t('New kitchen order')} #${n.order_no}`); }
    }
  }
  if (table === 'dining_tables') S.tables = await q(sb.from('dining_tables').select('*').order('code'));
  if (table === 'riders') S.riders = await q(sb.from('riders').select('*').order('rider_code'));
  if (table === 'products') S.products = await q(sb.from('products').select('*').eq('is_active', true).order('sort'));
  if (table === 'settings') S.settings = await loadSettings();
  if (table === 'profiles') S.waiters = await q(sb.from('profiles').select('*').eq('role', 'waiter'));
  refreshSoon();
}

/* ---------- order helpers ---------- */
const getOrder = async id => q(sb.from('orders').select(OSEL).eq('id', id).single());
const activeDelivery = o => {
  const ds = [...(o.deliveries || [])].sort((a, b) => a.id - b.id);
  return ds.find(d => ACTIVE_D.includes(d.status)) || [...ds].reverse().find(d => d.status === 'delivered');
};
const itemsLine = o => (o.order_items || []).map(i => `${i.qty}× ${esc(i.name)}${i.variant ? ` (${esc(i.variant)})` : ''}`).join(', ');

function orderActs(o) {
  const b = (act, label, cls = '') => `<button class="btn sm ${cls}" data-act="${act}" data-id="${o.id}">${t(label)}</button>`;
  const st = o.status;
  if (S.role === 'waiter') {
    // a waiter may only mark their own ready dine-in table as served
    return (st === 'ready' && o.fulfillment === 'dinein' && o.waiter_id === S.user.id) ? b('st_served', 'Served', 'primary') : '';
  }
  if (!isStaff()) return '';
  const a = [];
  if (st === 'pending') a.push(b('accept', 'ACCEPT', 'ok'), b('reject', 'REJECT', 'danger'));
  else if (st === 'accepted') a.push(b('st_preparing', 'Start Preparing'));
  else if (st === 'preparing') a.push(b('st_ready', 'Mark Ready', 'primary'));
  else if (st === 'ready') {
    if (o.fulfillment === 'delivery') a.push(b('assign', 'ASSIGN RIDER', 'primary'));
    else if (o.fulfillment === 'pickup') a.push(b('complete', 'Picked Up', 'primary'));
    else a.push(b('st_served', 'Served', 'primary'));
  } else if (st === 'served') a.push(b('complete', 'Complete', 'primary'));
  if (OPEN_ST.includes(st) && st !== 'pending' && o.payment_status !== 'paid') a.push(b('pay', 'Receive Payment'));
  return a.join('');
}
function deliveryActs(o) {
  const d = (o.deliveries || []).find(x => ACTIVE_D.includes(x.status)); if (!d) return '';
  const due = Math.max(0, num(o.total) - num(o.paid_amount));
  const b = (s, label, cls = '') => `<button class="btn sm ${cls}" data-act="dstat" data-id="${d.id}" data-s="${s}" data-due="${due}">${t(label)}</button>`;
  const a = [];
  if (d.status === 'assigned') a.push(b('accepted', 'Accepted'), b('picked_up', 'Picked Up', 'primary'));
  if (d.status === 'accepted') a.push(b('picked_up', 'Picked Up', 'primary'));
  if (d.status === 'picked_up') a.push(b('on_the_way', 'On the Way', 'primary'));
  if (d.status === 'on_the_way') a.push(b('delivered', 'DELIVERED', 'ok'));
  if (d.status !== 'assigned' || true) a.push(b('failed', 'Failed', 'danger'));
  if (isMgr()) a.push(`<button class="btn sm" data-act="reassign" data-id="${d.id}" data-oid="${o.id}">${t('REASSIGN RIDER')}</button>`);
  return a.join('');
}
function orderCard(o, { delivery = false } = {}) {
  const d = activeDelivery(o); const open = OPEN_ST.includes(o.status);
  return `<div class="ocard ${o.status === 'pending' ? 'new' : ''}">
    <div class="oh"><span class="on">#${esc(o.order_no)}</span>${srcTag(o.source)}${stPill(o.status)}</div>
    <div class="row wrap gap6"><span class="pill">${t(FUL[o.fulfillment])}</span>${o.tbl ? `<span class="pill">${t('Table')} ${esc(o.tbl.code)}</span>` : ''}${payPill(o.payment_status)}<span class="muted sm">${fmtTime(o.created_at)}${open ? ' · ' + ago(o.created_at) : ''}</span></div>
    ${o.customer_name || o.phone ? `<div class="sm">👤 ${esc(o.customer_name || '')} ${esc(o.phone || '')}</div>` : ''}
    ${o.fulfillment === 'delivery' && o.address ? `<div class="sm">📍 ${esc(o.address)}</div>` : ''}
    ${o.fulfillment === 'dinein' && o.waiter ? `<div class="sm">🧑‍🍳 ${esc(o.waiter.full_name)}${o.waiter.staff_id ? ` (${esc(o.waiter.staff_id)})` : ''}</div>` : ''}
    <div class="items">${itemsLine(o)}</div>
    ${o.notes ? `<div class="sm">📝 ${esc(o.notes)}</div>` : ''}
    ${d ? `<div class="sm">🏍️ ${esc(d.riders?.name || '')} — ${esc(d.riders?.rider_code || '')} · ${t(DSTATUS[d.status])}</div>` : (o.fulfillment === 'delivery' && open ? `<div class="sm muted">🏍️ ${t('Rider not assigned')}</div>` : '')}
    <div class="om"><span>${t('Total')}</span><span class="display">${money(o.total)}</span></div>
    <div class="acts">${orderActs(o)}${delivery ? deliveryActs(o) : ''}<button class="btn sm ghost" data-act="view" data-id="${o.id}">${t('View')}</button></div></div>`;
}

/* ---------- global click actions ---------- */
const ACT = {
  logout: () => Shell.logout(),
  accept: id => setStatus(id, 'accepted'),
  async reject(id) { const r = await askText(t('Reject order'), t('Reason (optional)')); if (r === null) return; await setStatus(id, 'rejected', r); },
  st_preparing: id => setStatus(id, 'preparing'),
  st_ready: id => setStatus(id, 'ready'),
  st_served: id => setStatus(id, 'served'),
  async complete(id) { const o = await getOrder(id); if (o.payment_status !== 'paid') return payModal(o, { thenComplete: true }); await setStatus(id, 'completed'); },
  assign: id => assignModal(id),
  async pay(id) { payModal(await getOrder(id)); },
  view: id => orderModal(id),
  async print(id) { Receipt.print(await getOrder(id), S.settings); },
  async cancel(id) {
    const r = await askText(t('Cancel order'), t('Reason'), { ok: 'Cancel order' }); if (r === null) return;
    await rpc('cancel_order', { p_order: +id, p_reason: r || '—' }); toast(t('Order cancelled')); refreshView();
  },
  async additems(id) {
    const o = await getOrder(id); S.cart = newCart();
    S.cart.addTo = { id: o.id, order_no: o.order_no, table: o.tbl ? o.tbl.code : null }; location.hash = '#/pos';
    if (S.view === 'pos') VIEWS.pos.render();
  },
  async closetable(id) {
    if (!await confirmBox(t('Close this table? All its orders will be completed.'), { ok: 'Close Table' })) return;
    await rpc('close_table', { p_table: +id }); toast(t('Table closed')); refreshView();
  },
  async dstat(id, el) {
    const s = el.dataset.s; let cash = null;
    if (s === 'failed' && !await confirmBox(t('Mark this delivery as failed? The order goes back to READY.'), { danger: true })) return;
    if (s === 'delivered' && num(el.dataset.due) > 0) {
      const v = await askText(t('Cash collected from customer'), t('Amount (Rs.)'), { value: el.dataset.due, type: 'number', ok: 'DELIVERED' }); if (v === null) return; cash = num(v);
    }
    await rpc('update_delivery_status', { p_delivery: +id, p_status: s, p_cash: cash }); toast(t('Delivery updated')); refreshView();
  },
  async reassign(id, el) { assignModal(el.dataset.oid, { reassign: +id }); }
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const fn = ACT[el.dataset.act]; if (!fn) return;
  e.preventDefault();
  if (el.dataset.closes) Modal.close(el.closest('.modal-wrap'));
  safe(() => fn(el.dataset.id, el, e), { busy: el });
});
async function setStatus(id, s, reason) {
  await rpc('set_order_status', { p_order: +id, p_status: s, p_reason: reason || null });
  refreshView(); updateBadge();
}

/* ---------- order detail modal ---------- */
async function orderModal(id) {
  const o = await getOrder(id);
  const pays = isStaff() ? await q(sb.from('payments').select('*').eq('order_id', id).order('created_at')) : [];
  const d = activeDelivery(o); const open = OPEN_ST.includes(o.status);
  const canCancel = open && (isMgr() || ((S.settings.permissions || {}).cashier_can_cancel && ['pending', 'accepted'].includes(o.status)));
  const cb = (act, label, cls = '') => `<button class="btn sm ${cls}" data-act="${act}" data-id="${o.id}" data-closes="1">${t(label)}</button>`;
  const rows = (o.order_items || []).sort((a, b) => a.id - b.id).map(i => `<tr><td>${i.qty} × <b>${esc(i.name)}</b>${i.variant ? ` (${esc(i.variant)})` : ''}${(i.addons || []).length ? `<div class="sm muted">+ ${i.addons.map(a => esc(a.name)).join(', ')}</div>` : ''}${i.note ? `<div class="sm muted">“${esc(i.note)}”</div>` : ''}</td><td class="num">${money(i.line_total)}</td></tr>`).join('');
  const tr = (l, v, cls = '') => `<div class="tot-row ${cls}"><span>${t(l)}</span><span>${v}</span></div>`;
  Modal.open({
    title: `#${o.order_no}`, wide: true, html: `
    <div class="row wrap gap6">${srcTag(o.source)}${stPill(o.status)}<span class="pill">${t(FUL[o.fulfillment])}</span>${o.tbl ? `<span class="pill">${t('Table')} ${esc(o.tbl.code)}</span>` : ''}${payPill(o.payment_status)}<span class="muted sm">${fmtDT(o.created_at)}${o.creator ? ' · ' + esc(o.creator.full_name) : ''}</span></div>
    ${o.customer_name || o.phone || o.address ? `<div class="card"><div>👤 <b>${esc(o.customer_name || '—')}</b> ${o.phone ? `<a href="tel:${esc(o.phone)}">${esc(o.phone)}</a>` : ''}</div>${o.address ? `<div>📍 ${esc(o.address)}</div>` : ''}${o.notes ? `<div>📝 ${esc(o.notes)}</div>` : ''}${o.waiter ? `<div>🧑‍🍳 ${t('Served By')}: ${esc(o.waiter.full_name)}${o.waiter.staff_id ? ` (${esc(o.waiter.staff_id)})` : ''}</div>` : ''}</div>` : ''}
    <div class="tbl-wrap"><table class="tbl"><tbody>${rows}</tbody></table></div>
    <div class="card">${tr('Subtotal', money(o.subtotal))}${num(o.discount) ? tr('Discount', '− ' + money(o.discount)) : ''}${num(o.delivery_fee) ? tr('Delivery', money(o.delivery_fee)) : ''}${num(o.tax) ? tr('Tax', money(o.tax)) : ''}${num(o.service_charge) ? tr('Service charge', money(o.service_charge)) : ''}${tr('Total', money(o.total), 'grand')}${tr('Paid', money(o.paid_amount))}${o.payment_status !== 'paid' ? tr('Remaining', money(num(o.total) - num(o.paid_amount))) : ''}</div>
    ${pays.length ? `<div class="card"><b>${t('Payments')}</b>${pays.map(p => `<div class="tot-row sm"><span>${fmtDT(p.created_at)} · ${esc(p.method)}${p.reference ? ' · ' + esc(p.reference) : ''}</span><span>${money(p.amount)}</span></div>`).join('')}</div>` : ''}
    ${d ? `<div class="card">🏍️ <b>${esc(d.riders?.name || '')}</b> — ${esc(d.riders?.rider_code || '')} · ${t(DSTATUS[d.status])}</div>` : ''}
    ${o.cancel_reason ? `<div class="banner">${t('Reason')}: ${esc(o.cancel_reason)}</div>` : ''}
    <div class="acts row wrap">${isStaff() || S.role === 'waiter' ? orderActs(o).replace(/data-id/g, 'data-closes="1" data-id') : ''}${isStaff() && open && !['assigned', 'picked_up', 'on_the_way'].includes(o.status) && o.status !== 'pending' ? cb('additems', 'Add Items') : ''}${isStaff() ? cb('print', o.fulfillment === 'dinein' && open ? 'Generate Bill' : 'Print Receipt') : ''}${canCancel ? cb('cancel', 'Cancel order', 'danger') : ''}${isMgr() && d && ACTIVE_D.includes(d.status) ? `<button class="btn sm" data-act="reassign" data-closes="1" data-id="${d.id}" data-oid="${o.id}">${t('REASSIGN RIDER')}</button>` : ''}</div>`
  });
}

/* ---------- assign / reassign rider ---------- */
async function assignModal(orderId, { reassign } = {}) {
  const [o, riders] = await Promise.all([getOrder(orderId), q(sb.from('riders').select('*').eq('status', 'available').order('rider_code'))]);
  let sel = null;
  const w = Modal.open({
    title: t(reassign ? 'REASSIGN RIDER' : 'ASSIGN RIDER'), html: `
    <div class="card"><b>#${esc(o.order_no)}</b> · ${money(o.total)}<div>👤 ${esc(o.customer_name || '')} ${esc(o.phone || '')}</div><div>📍 ${esc(o.address || '')}</div></div>
    <div class="muted b sm">${t('Available Riders')} (${riders.length})</div>
    ${riders.length ? `<div class="rider-pick">${riders.map(r => `<button type="button" class="rp" data-r="${r.id}"><b>${esc(r.name)} — ${esc(r.rider_code)}</b><span class="sm">${esc(r.vehicle_type)} ${esc(r.vehicle_no || '')}</span></button>`).join('')}</div>` : `<div class="empty">${t('No rider is available right now')}</div>`}
    <button class="btn primary lg" id="as-go" disabled>${t('ASSIGN RIDER')}</button>`
  });
  w.addEventListener('click', e => {
    const b = e.target.closest('.rp'); if (!b) return;
    sel = +b.dataset.r; $$('.rp', w).forEach(x => x.classList.toggle('on', x === b)); $('#as-go', w).disabled = false;
  });
  $('#as-go', w).onclick = ev => safe(async () => {
    if (reassign) await rpc('reassign_rider', { p_delivery: reassign, p_rider: sel });
    else await rpc('assign_rider', { p_order: +orderId, p_rider: sel });
    Modal.close(w); toast(t('Rider assigned')); refreshView();
  }, { busy: ev.currentTarget });
}

/* ---------- payment modal ---------- */
function payModal(o, { thenComplete = false } = {}) {
  const due = Math.max(0, num(o.total) - num(o.paid_amount));
  const methods = S.settings.payment_methods || ['Cash', 'Card', 'Online Payment']; let method = methods[0]; const cref = uuid();
  const w = Modal.open({
    title: `${t('Receive Payment')} · #${o.order_no}`, html: `
    <div class="tot-row"><span>${t('Total')}</span><b>${money(o.total)}</b></div><div class="tot-row"><span>${t('Paid')}</span><b>${money(o.paid_amount)}</b></div>
    <div class="tot-row grand"><span>${t('Remaining')}</span><span>${money(due)}</span></div>
    <div class="chips" id="pm">${methods.map((m, i) => `<button type="button" class="chip ${i ? '' : 'on'}" data-m="${esc(m)}">${esc(m)}</button>`).join('')}</div>
    <label class="f">${t('Amount received')}<input id="pm-amt" type="number" inputmode="decimal" value="${due}" min="1"></label>
    <div class="chips" id="pm-q"><button type="button" class="chip" data-a="${due}">${t('Exact')}</button>${[500, 1000, 5000].map(a => `<button type="button" class="chip" data-a="${a}">${a}</button>`).join('')}</div>
    <div id="pm-info" class="b"></div><button class="btn ok lg" id="pm-go">${t('Receive Payment')}</button>`
  });
  const info = () => {
    const a = num($('#pm-amt', w).value);
    $('#pm-info', w).textContent = a >= due ? `${t('Paid')}${a > due ? ` · ${t('Change')}: ${money(a - due)}` : ''}` : a > 0 ? `${t('Partial')} · ${t('Remaining')}: ${money(due - a)}` : '';
  };
  info();
  w.addEventListener('click', e => {
    const m = e.target.closest('[data-m]'); const a = e.target.closest('[data-a]');
    if (m) { method = m.dataset.m; $$('#pm .chip', w).forEach(c => c.classList.toggle('on', c === m)); }
    if (a) { $('#pm-amt', w).value = a.dataset.a; info(); }
  });
  $('#pm-amt', w).oninput = info;
  $('#pm-go', w).onclick = ev => safe(async () => {
    const amt = num($('#pm-amt', w).value); if (amt <= 0) throw new Error(t('Enter the amount'));
    await rpc('record_payment', { p_order: o.id, p_method: method, p_amount: Math.min(amt, due), p_ref: null, p_cref: cref });
    Modal.close(w);
    if (thenComplete && amt >= due) await rpc('set_order_status', { p_order: o.id, p_status: 'completed', p_reason: null });
    toast(t('Payment received')); refreshView();
    if (amt >= due) showReceipt(await getOrder(o.id));
  }, { busy: ev.currentTarget });
}

/* ---------- receipt modal ---------- */
function showReceipt(o, { newOrderBtn = false } = {}) {
  const w = Modal.open({
    title: t('Receipt'), html: `${Receipt.body(o, S.settings)}
    <div class="muted b sm">${t('Print size')}</div>
    <div class="chips"><button type="button" class="chip on" data-sz="80">80mm</button><button type="button" class="chip" data-sz="58">58mm</button><button type="button" class="chip" data-sz="a4">A4</button></div>
    <div class="row wrap"><button class="btn primary grow" id="rc-print">🖨 ${t('PRINT')}</button><button class="btn grow" id="rc-dl">⬇ ${t('DOWNLOAD')}</button>${newOrderBtn ? `<button class="btn dark grow" id="rc-new">➕ ${t('NEW ORDER')}</button>` : ''}</div>`
  });
  let size = '80';
  w.addEventListener('click', e => { const c = e.target.closest('[data-sz]'); if (c) { size = c.dataset.sz; $$('[data-sz]', w).forEach(x => x.classList.toggle('on', x === c)); } });
  $('#rc-print', w).onclick = () => Receipt.print(o, S.settings, size);
  $('#rc-dl', w).onclick = () => Receipt.download(o, S.settings);
  if (newOrderBtn) $('#rc-new', w).onclick = () => { Modal.close(w); location.hash = '#/pos'; if (S.view === 'pos') VIEWS.pos.render(); };
}
