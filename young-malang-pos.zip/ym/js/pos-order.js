/* =====================================================================
   THE YOUNG MALANG — POS screen (New Order) + cart engine
   ===================================================================== */
function newCart() { return { source: S.role === 'waiter' ? 'dinein' : 'walkin', fulfillment: S.role === 'waiter' ? 'dinein' : 'pickup', table_id: null, waiter_id: S.role === 'waiter' ? S.user.id : null, items: [], customer: {}, discount: { type: 'amount', value: 0 }, payNow: false, payAmt: 0, payMethod: null, addTo: null, ref: uuid() }; }

const SRC_FUL = { walkin: 'pickup', dinein: 'dinein', takeaway: 'pickup', phone: 'pickup', online: 'delivery', qr: 'dinein' };
function cartCalc(c) {
  const sub = c.items.reduce((s, i) => s + (i.base + i.addons.reduce((a, x) => a + x.price, 0)) * i.qty, 0);
  const disc = Math.min(sub, c.discount.type === 'percent' ? Math.round(sub * num(c.discount.value) / 100) : num(c.discount.value));
  const chg = S.settings.charges || {};
  let delivery = 0; if (c.fulfillment === 'delivery') { delivery = num(chg.delivery_fee); if (num(chg.free_delivery_above) > 0 && sub >= num(chg.free_delivery_above)) delivery = 0; }
  const net = sub - disc;
  const tax = Math.round(net * num(chg.tax_pct) / 100);
  const svc = c.fulfillment === 'dinein' ? Math.round(net * num(chg.service_charge_pct) / 100) : 0;
  return { sub, disc, delivery, tax, svc, total: net + delivery + tax + svc };
}
const cashierDiscMax = () => S.role === 'cashier' ? num((S.settings.permissions || {}).cashier_max_discount_pct) : 100;

VIEWS.pos = {
  cat: null, q: '',
  render() {
    if (!S.cart) S.cart = newCart();
    const c = S.cart;
    $('#view').innerHTML = `<div class="pos" id="pos-wrap">
      <div class="pos-col cats" id="pos-cats"></div>
      <div class="pos-col" id="pos-prods"></div>
      <div class="cart" id="pos-cart"></div>
      <button class="btn primary cart-toggle" id="cart-toggle">🛒 ${t('View Order')}</button></div>`;
    this.cat = this.cat || (S.cats[0] && S.cats[0].id);
    this.paintCats(); this.paintProds(); this.paintCart();
    $('#cart-toggle').onclick = () => $('#pos-wrap').classList.toggle('cart-open');
  },
  refresh() { this.paintProds(); this.paintCart(); },
  paintCats() {
    $('#pos-cats').innerHTML = S.cats.map(c => `<button class="cat ${c.id === this.cat ? 'on' : ''}" data-cat="${c.id}">${catEmoji(c.name)} ${esc(pick(c))}</button>`).join('');
    $$('#pos-cats .cat').forEach(b => b.onclick = () => { this.cat = +b.dataset.cat; this.paintCats(); this.paintProds(); });
  },
  paintProds() {
    const list = S.products.filter(p => p.category_id === this.cat && (!this.q || pick(p).toLowerCase().includes(this.q.toLowerCase())));
    $('#pos-prods').innerHTML = `<div class="prod-tools"><input id="pos-search" placeholder="${t('Search products')}" value="${esc(this.q)}"></div>
      <div class="prod-grid">${list.map(p => `<button type="button" class="pcard ${p.is_available ? '' : 'off'}" data-p="${p.id}">
        ${p.image_url ? `<img src="${esc(p.image_url)}" alt="">` : `<div class="ph">${catEmoji((S.cats.find(c => c.id === p.category_id) || {}).name)}</div>`}
        <div class="pi"><div class="pn">${esc(pick(p))}</div><div class="pp">${money(p.price) === money(0) ? t('From') + ' ' + money(Math.min(...S.variants.filter(v => v.product_id === p.id).map(v => v.price), Infinity)) : money(p.price)}</div>${!p.is_available ? `<span class="pill bad sm">${t('Unavailable')}</span>` : ''}</div></button>`).join('') || `<div class="empty">${t('No products')}</div>`}</div>`;
    $('#pos-search').oninput = debounce(e => { this.q = e.target.value; this.paintProds(); }, 200);
    $$('#pos-prods .pcard:not(.off)').forEach(b => b.onclick = () => {
      const p = S.products.find(x => x.id === +b.dataset.p);
      openItemPicker({ product: p, variants: S.variants, addons: S.addons, onAdd: it => { S.cart.items.push(it); this.paintCart(); toast(`${t('Added')}: ${pick(p)}`); } });
    });
  },
  paintCart() {
    const c = S.cart, box = $('#pos-cart'); const calc = cartCalc(c);
    const addNote = c.addTo ? `<div class="banner">${t('Adding items to')} #${esc(c.addTo.order_no)}${c.addTo.table ? ' · ' + t('Table') + ' ' + esc(c.addTo.table) : ''} <button class="btn sm ghost" id="cart-cancel-add">${t('Cancel')}</button></div>` : '';
    const srcOptions = S.role === 'waiter' ? ['dinein'] : Object.keys(SRC);
    box.innerHTML = `<div class="cart-h">
        ${addNote}
        ${!c.addTo ? `<div class="chips" id="cart-src">${srcOptions.map(s => `<button type="button" class="chip ${c.source === s ? 'on' : ''}" data-src="${s}">${t(SRC[s])}</button>`).join('')}</div>` : ''}
        ${!c.addTo && c.fulfillment !== 'dinein' ? `<div class="chips" id="cart-ful">${['pickup', 'delivery'].map(f => `<button type="button" class="chip ${c.fulfillment === f ? 'on' : ''}" data-ful="${f}">${t(FUL[f])}</button>`).join('')}</div>` : ''}
        ${!c.addTo && c.fulfillment === 'dinein' ? this.tablePicker() : ''}
        ${!c.addTo && c.fulfillment === 'dinein' && S.role !== 'waiter' ? this.waiterPicker() : ''}</div>
      <div class="cart-lines" id="cart-lines"></div>
      <div class="cart-f" id="cart-f"></div>`;
    this.paintLines(); this.paintFooter(calc);
    if (!c.addTo) {
      $$('#cart-src .chip').forEach(b => b.onclick = () => { c.source = b.dataset.src; c.fulfillment = SRC_FUL[c.source]; if (c.source !== 'qr') c.table_id = c.table_id; this.paintCart(); });
      const fulBox = $('#cart-ful'); if (fulBox) $$('#cart-ful .chip').forEach(b => b.onclick = () => { c.fulfillment = b.dataset.ful; this.paintCart(); });
      const tp = $('#cart-table'); if (tp) tp.onchange = () => { c.table_id = +tp.value || null; };
      const wp = $('#cart-waiter'); if (wp) wp.onchange = () => { c.waiter_id = wp.value || null; };
    }
    box.querySelectorAll('[data-close-cart]').forEach(b => b.onclick = () => $('#pos-wrap').classList.remove('cart-open'));
    const ca = $('#cart-cancel-add'); if (ca) ca.onclick = () => { S.cart.addTo = null; this.paintCart(); };
  },
  tablePicker() {
    const c = S.cart; const avail = S.tables.filter(t2 => t2.status === 'available' || t2.id === c.table_id);
    return `<select id="cart-table"><option value="">${t('Select table')}…</option>${avail.map(t2 => `<option value="${t2.id}" ${c.table_id === t2.id ? 'selected' : ''}>${esc(t2.code)}</option>`).join('')}</select>`;
  },
  waiterPicker() {
    const c = S.cart; const avail = S.waiters.filter(w => w.waiter_status !== 'inactive');
    if (!avail.length) return '';
    return `<select id="cart-waiter"><option value="">${t('Served By (optional)')}…</option>${avail.map(w => `<option value="${w.id}" ${c.waiter_id === w.id ? 'selected' : ''}>${esc(w.full_name)}${w.staff_id ? ` (${esc(w.staff_id)})` : ''}</option>`).join('')}</select>`;
  },
  paintLines() {
    const c = S.cart;
    $('#cart-lines').innerHTML = c.items.length ? c.items.map((i, idx) => `<div class="line">
      <span class="ln">${esc(pick({ name: i.name, name_ur: i.name_ur }))}${i.variant_name ? ` · ${esc(i.variant_name)}` : ''}</span><span class="lp">${money((i.base + i.addons.reduce((a, x) => a + x.price, 0)) * i.qty)}</span>
      ${i.addons.length ? `<span class="lm">+ ${i.addons.map(a => esc(a.name)).join(', ')}</span>` : ''}${i.note ? `<span class="lm">“${esc(i.note)}”</span>` : ''}
      <span class="lc"><span class="qty"><button data-q="-1" data-i="${idx}">−</button><span>${i.qty}</span><button data-q="1" data-i="${idx}">+</button></span><button class="icon-btn" data-rm="${idx}">🗑</button></span></div>`).join('')
      : `<div class="empty">${t('No items yet — tap a product to add it')}</div>`;
    $$('#cart-lines [data-q]').forEach(b => b.onclick = () => { const i = c.items[+b.dataset.i]; i.qty = Math.max(1, i.qty + +b.dataset.q); this.paintCart(); });
    $$('#cart-lines [data-rm]').forEach(b => b.onclick = () => { c.items.splice(+b.dataset.rm, 1); this.paintCart(); });
  },
  paintFooter(calc) {
    const c = S.cart;
    $('#cart-f').innerHTML = `
      ${calc.disc ? `<div class="tot-row"><span>${t('Discount')}</span><span>− ${money(calc.disc)}</span></div>` : ''}
      ${calc.delivery ? `<div class="tot-row"><span>${t('Delivery')}</span><span>${money(calc.delivery)}</span></div>` : ''}
      ${calc.tax ? `<div class="tot-row"><span>${t('Tax')}</span><span>${money(calc.tax)}</span></div>` : ''}
      ${calc.svc ? `<div class="tot-row"><span>${t('Service charge')}</span><span>${money(calc.svc)}</span></div>` : ''}
      <div class="tot-row"><span>${t('Subtotal')}</span><span>${money(calc.sub)}</span></div>
      <div class="tot-row grand"><span>${t('TOTAL')}</span><span>${money(calc.total)}</span></div>
      <div class="cart-btns">
        <button class="btn sm ghost" id="cb-disc">% ${t('Discount')}</button>
        <button class="btn sm ghost" id="cb-note">📝 ${t('Note')}</button>
        <button class="btn sm ghost" id="cb-clear">${t('Clear')}</button>
        <button class="btn sm ghost only-mobile" data-close-cart>${t('Close')}</button>
      </div>
      <button class="btn primary lg block" id="cb-checkout" ${c.items.length ? '' : 'disabled'}>${t(c.addTo ? 'Add Items' : 'Checkout')} · ${money(calc.total)}</button>`;
    $('#cb-clear').onclick = async () => { if (!c.items.length || await confirmBox(t('Clear the current order?'))) { S.cart = c.addTo ? Object.assign(newCart(), { addTo: c.addTo }) : newCart(); this.paintCart(); } };
    $('#cb-note').onclick = async () => { const v = await askText(t('Order note'), t('Note'), { value: c.notes || '', textarea: true }); if (v !== null) c.notes = v; };
    $('#cb-disc').onclick = () => this.discountModal(calc);
    $('#cb-checkout').onclick = () => c.addTo ? this.submitAddItems() : this.openCheckout(calc);
  },
  discountModal(calc) {
    const c = S.cart; const max = cashierDiscMax();
    const w = Modal.open({
      title: t('Apply Discount'), html: `
      <div class="chips"><button type="button" class="chip ${c.discount.type === 'amount' ? 'on' : ''}" data-dt="amount">Rs.</button><button type="button" class="chip ${c.discount.type === 'percent' ? 'on' : ''}" data-dt="percent">%</button></div>
      <label class="f">${t('Value')}<input id="disc-v" type="number" value="${c.discount.value || ''}" min="0"></label>
      ${S.role === 'cashier' ? `<div class="sm muted">${t('Your limit')}: ${max}%</div>` : ''}
      <button class="btn primary lg" id="disc-go">${t('Apply')}</button>`
    });
    let type = c.discount.type;
    w.addEventListener('click', e => { const b = e.target.closest('[data-dt]'); if (b) { type = b.dataset.dt; $$('[data-dt]', w).forEach(x => x.classList.toggle('on', x === b)); } });
    $('#disc-go', w).onclick = () => {
      const v = num($('#disc-v', w).value);
      if (S.role === 'cashier') { const pct = type === 'percent' ? v : (calc.sub ? v / calc.sub * 100 : 0); if (pct > max + 0.001) return toast(t('Discount exceeds your limit'), 'err'); }
      c.discount = { type, value: v }; Modal.close(w); this.paintCart();
    };
  },
  async submitAddItems() {
    const c = S.cart;
    const items = c.items.map(i => ({ product_id: i.product_id, variant_id: i.variant_id, qty: i.qty, addon_ids: i.addons.map(a => a.id), note: i.note }));
    await safe(async () => {
      await rpc('add_items', { p_order: c.addTo.id, p_items: items });
      toast(t('Items added to kitchen')); S.cart = newCart(); this.render(); refreshView();
    });
  },
  openCheckout(calc) {
    const c = S.cart;
    if (c.fulfillment === 'dinein' && !c.table_id) return toast(t('Please select a table'), 'err');
    const needCust = c.fulfillment === 'delivery';
    const methods = S.settings.payment_methods || ['Cash', 'Card', 'Online Payment'];
    const w = Modal.open({
      title: t('Checkout') + ` · ${money(calc.total)}`, html: `
      <div class="form-grid">
        <label class="f">${t('Customer Name')}${needCust ? ' *' : ''}<input id="co-name" value="${esc(c.customer.name || '')}"></label>
        <label class="f">${t('Phone Number')}${needCust ? ' *' : ''}<input id="co-phone" value="${esc(c.customer.phone || '')}" inputmode="tel"></label>
        ${c.fulfillment === 'delivery' ? `<label class="f full">${t('Address')} *<textarea id="co-addr">${esc(c.customer.address || '')}</textarea></label>` : ''}
      </div>
      <div class="row" id="co-lookup"><button class="btn sm ghost" id="co-find" type="button">${t('Search repeat customer')}</button></div>
      <div class="muted b sm">${t('Payment Method')}</div>
      <div class="chips" id="co-pm">${methods.map((m, i) => `<button type="button" class="chip ${i ? '' : 'on'}" data-m="${esc(m)}">${esc(m)}</button>`).join('')}</div>
      <div class="chips"><button type="button" class="chip ${c.payAmt >= calc.total ? 'on' : ''}" data-pay="full">${t('Paid in full')}</button><button type="button" class="chip" data-pay="partial">${t('Partial')}</button><button type="button" class="chip" data-pay="later">${t('Pay later')}</button></div>
      <label class="f hidden" id="co-amt-wrap">${t('Amount received')}<input id="co-amt" type="number" value="${calc.total}"></label>
      <button class="btn primary lg" id="co-go">${t('Confirm order')}</button>`
    });
    let method = methods[0], mode = 'later';
    w.addEventListener('click', e => {
      const m = e.target.closest('[data-m]'); if (m) { method = m.dataset.m; $$('#co-pm .chip', w).forEach(x => x.classList.toggle('on', x === m)); }
      const p = e.target.closest('[data-pay]'); if (p) {
        mode = p.dataset.pay; $$('[data-pay]', w).forEach(x => x.classList.toggle('on', x === p));
        $('#co-amt-wrap', w).classList.toggle('hidden', mode === 'later');
        if (mode === 'full') $('#co-amt', w).value = calc.total;
        if (mode === 'partial' && +$('#co-amt', w).value === calc.total) $('#co-amt', w).value = '';
      }
    });
    $('#co-find', w).onclick = async () => {
      const term = await askText(t('Search repeat customer'), t('Name, phone or order number'));
      if (!term) return;
      const rows = await q(sb.from('customers').select('*').or(`phone.ilike.%${term}%,name.ilike.%${term}%`).limit(5));
      if (!rows.length) return toast(t('No customer found'), 'err');
      const cu = rows[0]; $('#co-name', w).value = cu.name || ''; $('#co-phone', w).value = cu.phone || ''; if ($('#co-addr', w)) $('#co-addr', w).value = cu.address || '';
      toast(`${t('Found')}: ${cu.name || cu.phone}`);
    };
    $('#co-go', w).onclick = ev => safe(async () => {
      const name = $('#co-name', w).value.trim(), phone = $('#co-phone', w).value.trim(), addr = $('#co-addr', w) ? $('#co-addr', w).value.trim() : '';
      if (needCust && (!name || !phone || !addr)) throw new Error(t('Delivery needs customer name, phone and address'));
      const payAmt = mode === 'later' ? 0 : mode === 'full' ? calc.total : num($('#co-amt', w).value);
      const payload = {
        client_ref: c.ref, source: c.source, fulfillment: c.fulfillment, table_id: c.table_id, waiter_id: c.waiter_id || null,
        customer: { name, phone, address: addr, notes: c.customer.notes }, notes: c.notes || null,
        items: c.items.map(i => ({ product_id: i.product_id, variant_id: i.variant_id, qty: i.qty, addon_ids: i.addons.map(a => a.id), note: i.note })),
        discount: c.discount, payment: payAmt > 0 ? { amount: payAmt, method } : null
      };
      const res = await rpc('create_order', payload);
      Modal.close(w); toast(`${t('Order created')}: #${res.order_no}`);
      const o = await getOrder(res.id); S.cart = newCart(); this.render(); refreshView(); updateBadge();
      showReceipt(o, { newOrderBtn: true });
    }, { busy: ev.currentTarget });
  }
};
