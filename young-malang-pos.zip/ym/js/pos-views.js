/* =====================================================================
   THE YOUNG MALANG — POS remaining views
   ===================================================================== */

/* ---------- DASHBOARD ---------- */
VIEWS.dashboard = {
  async render() {
    $('#view').innerHTML = `<div id="dash"></div>`;
    await this.refresh();
  },
  async refresh() {
    const start = startOfDay().toISOString();
    const orders = await q(sb.from('orders').select('source, fulfillment, status, total, payment_status, payment_method').gte('created_at', start));
    const openOrders = orders.filter(o => OPEN_ST.includes(o.status));
    const done = orders.filter(o => ['completed', 'delivered'].includes(o.status));
    const sales = done.reduce((s, o) => s + num(o.total), 0);
    const by = f => orders.filter(f).length;
    const av = S.riders.filter(r => r.status === 'available').length, od = S.riders.filter(r => r.status === 'on_delivery').length;
    const pendDel = orders.filter(o => o.fulfillment === 'delivery' && ['ready'].includes(o.status)).length;
    const cash = done.filter(o => o.payment_method === 'Cash').reduce((s, o) => s + num(o.total), 0);
    const card = done.filter(o => o.payment_method === 'Card').reduce((s, o) => s + num(o.total), 0);
    const stat = (v, l, hero) => `<div class="stat ${hero ? 'hero' : ''}"><div class="v">${v}</div><div class="l">${t(l)}</div></div>`;
    $('#dash').innerHTML = `
      <div class="view-head"><h2>${t('Dashboard')}</h2></div>
      <div class="stats">
        ${stat(orders.length, 'Total Orders', true)}${stat(money(sales), 'Total Sales', true)}
        ${stat(by(o => o.source === 'online'), 'Online Orders')}${stat(by(o => ['walkin', 'phone'].includes(o.source)), 'Manual Orders')}
        ${stat(by(o => o.source === 'qr'), 'QR Orders')}${stat(by(o => o.source === 'phone'), 'Phone Orders')}
        ${stat(by(o => o.fulfillment === 'dinein'), 'Dine-in Orders')}${stat(by(o => o.fulfillment === 'pickup'), 'Takeaway Orders')}
        ${stat(by(o => o.status === 'pending'), 'Pending Orders')}${stat(by(o => o.status === 'preparing'), 'Preparing Orders')}
        ${stat(by(o => o.status === 'ready'), 'Ready Orders')}${stat(done.length, 'Completed Orders')}
      </div>
      <div class="section-h">${t('Delivery')}</div>
      <div class="stats">${stat(av, 'Available Riders')}${stat(od, 'Riders On Delivery')}${stat(pendDel, 'Pending Deliveries')}${stat(money(cash), 'Cash Sales')}${stat(money(card), 'Card Sales')}</div>
      <div class="section-h">${t('Quick Actions')}</div>
      <div class="quick">
        ${[['pos', '➕', 'New Order'], ['online', '🌐', 'Online Orders'], ['manual', '✍️', 'Manual Orders'], ['tables', '🍽️', 'Tables'], ['kitchen', '👨‍🍳', 'Kitchen'], ['delivery', '🛵', 'Delivery'], ['riders', '🏍️', 'Riders'], ['payments', '💳', 'Payments'], ['reports', '📈', 'Reports']]
          .filter(([id]) => allowedViews().includes(id)).map(([id, ic, l]) => `<button class="btn" data-nav="${id}"><span class="ic">${ic}</span>${t(l)}</button>`).join('')}
      </div>`;
  }
};

/* ---------- ORDERS (all) ---------- */
function orderListView(id, title, filterFn) {
  VIEWS[id] = {
    f: { range: 'today', status: '', src: '', q: '' },
    async render() {
      $('#view').innerHTML = `<div class="view-head"><h2>${t(title)}</h2></div>
        <div class="olist-tools">
          <input id="ol-q" placeholder="${t('Order #, name, phone…')}" value="${esc(this.f.q)}">
          <select id="ol-range"><option value="today">${t('Today')}</option><option value="yesterday">${t('Yesterday')}</option><option value="7">${t('Last 7 days')}</option><option value="30">${t('Last 30 days')}</option><option value="all">${t('All')}</option></select>
          <select id="ol-status"><option value="">${t('All statuses')}</option>${Object.entries(STATUS).map(([k, v]) => `<option value="${k}">${t(v)}</option>`).join('')}</select>
          ${id === 'orders' ? `<select id="ol-src"><option value="">${t('All sources')}</option>${Object.entries(SRC).map(([k, v]) => `<option value="${k}">${t(v)}</option>`).join('')}</select>` : ''}
        </div>
        <div class="ogrid" id="ol-grid"><div class="empty">${t('Loading')}…</div></div>`;
      $('#ol-range').value = this.f.range; $('#ol-status').value = this.f.status; if ($('#ol-src')) $('#ol-src').value = this.f.src;
      $('#ol-q').oninput = debounce(e => { this.f.q = e.target.value; this.load(); }, 300);
      $('#ol-range').onchange = e => { this.f.range = e.target.value; this.load(); };
      $('#ol-status').onchange = e => { this.f.status = e.target.value; this.load(); };
      if ($('#ol-src')) $('#ol-src').onchange = e => { this.f.src = e.target.value; this.load(); };
      await this.load();
    },
    refresh() { this.load(); },
    async load() {
      let qry = sb.from('orders').select(OSEL).order('created_at', { ascending: false }).limit(200);
      if (this.f.range === 'today') qry = qry.gte('created_at', startOfDay().toISOString());
      else if (this.f.range === 'yesterday') qry = qry.gte('created_at', addDays(startOfDay(), -1).toISOString()).lt('created_at', startOfDay().toISOString());
      else if (this.f.range === '7') qry = qry.gte('created_at', addDays(startOfDay(), -7).toISOString());
      else if (this.f.range === '30') qry = qry.gte('created_at', addDays(startOfDay(), -30).toISOString());
      if (this.f.status) qry = qry.eq('status', this.f.status);
      if (this.f.src) qry = qry.eq('source', this.f.src);
      if (this.f.q) qry = qry.or(`order_no.ilike.%${this.f.q}%,customer_name.ilike.%${this.f.q}%,phone.ilike.%${this.f.q}%`);
      let rows = await q(qry);
      if (filterFn) rows = rows.filter(filterFn);
      const grid = $('#ol-grid'); if (!grid) return;
      grid.innerHTML = rows.length ? rows.map(o => orderCard(o, { delivery: o.fulfillment === 'delivery' })).join('') : `<div class="empty">${t('No orders found')}</div>`;
    }
  };
}
orderListView('orders', 'Orders', null);
orderListView('online', 'Online Orders', o => isOnlineSrc(o.source));
orderListView('manual', 'Manual Orders', o => !isOnlineSrc(o.source));

/* ---------- TABLES ---------- */
VIEWS.tables = {
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Tables')}</h2></div><div class="tgrid" id="tg"></div>`;
    this.paint();
  },
  refresh() { this.paint(); },
  paint() {
    $('#tg').innerHTML = S.tables.map(tb => `<button type="button" class="tcard ${tb.status}" data-t="${tb.id}">
      <span class="tc">${esc(tb.code)}</span><span class="st">${t({ available: 'AVAILABLE', occupied: 'OCCUPIED', reserved: 'RESERVED' }[tb.status])}</span>
      <span class="sm muted">${tb.seats} ${t('seats')} · ${esc(tb.qr_code)}</span></button>`).join('');
    $$('#tg .tcard').forEach(b => b.onclick = () => this.open(+b.dataset.t));
  },
  async open(id) {
    const tb = S.tables.find(x => x.id === id);
    if (tb.status === 'available') {
      S.cart = newCart(); S.cart.source = 'dinein'; S.cart.fulfillment = 'dinein'; S.cart.table_id = id;
      location.hash = '#/pos'; if (S.view === 'pos') VIEWS.pos.render();
      return;
    }
    if (tb.status === 'reserved') {
      if (await confirmBox(t('Release this reservation?'))) await rpc('set_table_status', { p_table: id, p_status: 'available' });
      return;
    }
    // occupied
    const o = tb.current_order_id ? await getOrder(tb.current_order_id) : null;
    if (!o) return toast(t('No active order for this table'), 'err');
    orderModal(o.id);
  }
};

/* ---------- KITCHEN ---------- */
VIEWS.kitchen = {
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Kitchen')}</h2></div><div class="kds" id="kds"></div>`;
    await this.load();
  },
  refresh() { this.load(); },
  async load() {
    const rows = await q(sb.from('orders').select(OSEL).in('status', ['accepted', 'preparing', 'ready']).order('created_at'));
    const done = await q(sb.from('orders').select(OSEL).in('status', ['served', 'completed', 'delivered']).gte('updated_at', new Date(Date.now() - 20 * 60000).toISOString()).order('updated_at', { ascending: false }).limit(12));
    const col = (arr, empty) => arr.length ? arr.map(o => this.card(o)).join('') : `<div class="empty sm">${t(empty)}</div>`;
    $('#kds').innerHTML = `
      <div class="kcol"><h3>🆕 ${t('NEW')} <span class="pill">${rows.filter(o => o.status === 'accepted').length}</span></h3>${col(rows.filter(o => o.status === 'accepted'), 'No new orders')}</div>
      <div class="kcol"><h3>🔥 ${t('PREPARING')} <span class="pill">${rows.filter(o => o.status === 'preparing').length}</span></h3>${col(rows.filter(o => o.status === 'preparing'), 'Nothing preparing')}</div>
      <div class="kcol"><h3>✅ ${t('READY')} <span class="pill">${rows.filter(o => o.status === 'ready').length}</span></h3>${col(rows.filter(o => o.status === 'ready'), 'Nothing ready')}</div>
      <div class="kcol"><h3>🏁 ${t('COMPLETED')}</h3>${col(done, 'Nothing recent')}</div>`;
  },
  card(o) {
    const late = (Date.now() - new Date(o.confirmed_at || o.created_at)) > 20 * 60000 && ['accepted', 'preparing'].includes(o.status);
    const items = (o.order_items || []).map(i => `<div class="ki">${i.qty} × ${esc(i.name)}${i.variant ? ` <small>(${esc(i.variant)})</small>` : ''}${i.addons.length ? `<div class="add sm">+ ${i.addons.map(a => esc(a.name)).join(', ')}</div>` : ''}${i.note ? `<div class="note">${esc(i.note)}</div>` : ''}</div>`).join('');
    const next = { accepted: ['preparing', 'PREPARING'], preparing: ['ready', 'READY'] }[o.status];
    const done = ['served', 'completed', 'delivered'].includes(o.status);
    return `<div class="kcard ${late ? 'late' : ''} ${done ? 'done' : ''}">
      <div class="row"><span class="kn">#${esc(o.order_no)}</span>${srcTag(o.source)}${o.tbl ? `<span class="pill">${esc(o.tbl.code)}</span>` : ''}<span class="sm muted nowrap">${ago(o.confirmed_at || o.created_at)}</span></div>
      ${items}${o.notes ? `<div class="note">${esc(o.notes)}</div>` : ''}
      ${next && isStaff() || (next && S.role === 'kitchen') ? `<button class="btn ${o.status === 'accepted' ? '' : 'primary'} block" data-act="${o.status === 'accepted' ? 'st_preparing' : 'st_ready'}" data-id="${o.id}">${t(next[1])}</button>` : ''}</div>`;
  }
};

/* ---------- DELIVERY ---------- */
VIEWS.delivery = {
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Delivery')}</h2></div>
      <div class="section-h">${t('PENDING DELIVERY')}</div><div class="ogrid" id="dv-ready"></div>
      <div class="section-h">${t('ON DELIVERY')}</div><div class="ogrid" id="dv-active"></div>`;
    await this.load();
  },
  refresh() { this.load(); },
  async load() {
    const ready = await q(sb.from('orders').select(OSEL).eq('fulfillment', 'delivery').eq('status', 'ready').order('ready_at'));
    const active = await q(sb.from('orders').select(OSEL).eq('fulfillment', 'delivery').in('status', ['assigned', 'picked_up', 'on_the_way']).order('updated_at'));
    $('#dv-ready').innerHTML = ready.length ? ready.map(o => orderCard(o)).join('') : `<div class="empty">${t('No orders waiting for a rider')}</div>`;
    $('#dv-active').innerHTML = active.length ? active.map(o => orderCard(o, { delivery: true })).join('') : `<div class="empty">${t('No riders out right now')}</div>`;
  }
};

/* ---------- RIDERS ---------- */
VIEWS.riders = {
  f: 'all',
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Riders')}</h2>${isMgr() ? `<button class="btn primary" id="rd-add">➕ ${t('Add Rider')}</button>` : ''}</div>
      <div class="tabs" id="rd-tabs">${[['all', 'All'], ['available', 'Available'], ['on_delivery', 'On Delivery'], ['offline', 'Offline'], ['inactive', 'Inactive']].map(([k, l]) => `<button class="tab ${this.f === k ? 'on' : ''}" data-f="${k}">${t(l)}</button>`).join('')}</div>
      <div class="rgrid" id="rd-grid"></div>`;
    $$('#rd-tabs .tab').forEach(b => b.onclick = () => { this.f = b.dataset.f; this.render(); });
    if (isMgr()) $('#rd-add').onclick = () => this.editModal();
    this.paint();
  },
  refresh() { this.paint(); },
  async paint() {
    const rows = this.f === 'all' ? S.riders : S.riders.filter(r => r.status === this.f);
    const withCounts = await Promise.all(rows.map(async r => {
      const today = await q(sb.from('deliveries').select('status').eq('rider_id', r.id).gte('assigned_at', startOfDay().toISOString()));
      const active = await q(sb.from('deliveries').select('order_id, status, orders(order_no, customer_name)').eq('rider_id', r.id).in('status', ACTIVE_D).limit(1));
      return { r, today, active: active || [] };
    }));
    $('#rd-grid').innerHTML = withCounts.map(({ r, today, active }) => {
      const done = today.filter(d => d.status === 'delivered').length, act = active[0];
      return `<div class="rcard ${r.status}">
        <div class="row"><span class="dot ${RDOT[r.status]}"></span><span class="rn grow">${esc(r.name)}</span><span class="rid">${esc(r.rider_code)}</span></div>
        <dl class="kv"><dt>${t('Phone')}</dt><dd>${esc(r.phone || '—')}</dd><dt>${t('Vehicle')}</dt><dd>${esc(r.vehicle_type)} ${esc(r.vehicle_no || '')}</dd>
          <dt>${t("Today's Deliveries")}</dt><dd>${today.length}</dd><dt>${t('Completed')}</dt><dd>${done}</dd><dt>${t('Per Ride')}</dt><dd>${money(r.per_ride_rate)}</dd></dl>
        <span class="pill ${{ available: 'ok', on_delivery: 'warn', offline: 'gray', inactive: 'bad' }[r.status]}">${t(RSTATUS[r.status])}</span>
        ${act ? `<div class="sm">#${esc(act.orders?.order_no || '')} — ${esc(act.orders?.customer_name || '')}</div>` : ''}
        <div class="acts row wrap">
          ${r.status === 'offline' ? `<button class="btn sm ok" data-rst="available" data-r="${r.id}">${t('Go Available')}</button>` : ''}
          ${r.status === 'available' ? `<button class="btn sm ghost" data-rst="offline" data-r="${r.id}">${t('Go Offline')}</button>` : ''}
          ${isMgr() ? `<button class="btn sm ghost" data-redit="${r.id}">${t('Edit')}</button>` : ''}
          ${isMgr() ? `<button class="btn sm ghost" data-earn="${r.id}">${t('Earnings')}</button>` : ''}
          ${isMgr() && r.status !== 'inactive' ? `<button class="btn sm danger" data-rst="inactive" data-r="${r.id}">${t('Disable')}</button>` : ''}
          ${isMgr() && r.status === 'inactive' ? `<button class="btn sm ok" data-rst="offline" data-r="${r.id}">${t('Enable')}</button>` : ''}
        </div></div>`;
    }).join('') || `<div class="empty">${t('No riders')}</div>`;
    $$('#rd-grid [data-rst]').forEach(b => b.onclick = () => safe(async () => { await rpc('set_rider_status', { p_rider: +b.dataset.r, p_status: b.dataset.rst }); toast(t('Rider updated')); }, { busy: b }));
    $$('#rd-grid [data-redit]').forEach(b => b.onclick = () => this.editModal(S.riders.find(r => r.id === +b.dataset.redit)));
    $$('#rd-grid [data-earn]').forEach(b => b.onclick = () => this.earnModal(S.riders.find(r => r.id === +b.dataset.earn)));
  },
  editModal(r) {
    const w = Modal.open({
      title: t(r ? 'Edit Rider' : 'Add Rider'), html: `<div class="form-grid">
      <label class="f">${t('Rider Name')}<input id="r-name" value="${esc(r?.name || '')}"></label>
      <label class="f">${t('Phone Number')}<input id="r-phone" value="${esc(r?.phone || '')}"></label>
      <label class="f">${t('Vehicle Type')}<select id="r-veh"><option ${r?.vehicle_type === 'Bike' ? 'selected' : ''}>Bike</option><option ${r?.vehicle_type === 'Car' ? 'selected' : ''}>Car</option><option ${r?.vehicle_type === 'Bicycle' ? 'selected' : ''}>Bicycle</option></select></label>
      <label class="f">${t('Vehicle Number')}<input id="r-vno" value="${esc(r?.vehicle_no || '')}"></label>
      <label class="f">${t('Per Ride')} (Rs.)<input id="r-rate" type="number" value="${r?.per_ride_rate ?? (num((S.settings.rider || {}).default_rate) || 100)}"></label></div>
      ${r ? `<div class="sm muted">${t('Rider ID')}: <b>${esc(r.rider_code)}</b> (${t('permanent')})</div>` : ''}
      <button class="btn primary lg" id="r-save">${t('Save')}</button>`
    });
    $('#r-save', w).onclick = ev => safe(async () => {
      const payload = { name: $('#r-name', w).value.trim(), phone: $('#r-phone', w).value.trim(), vehicle_type: $('#r-veh', w).value, vehicle_no: $('#r-vno', w).value.trim(), per_ride_rate: num($('#r-rate', w).value) };
      if (!payload.name) throw new Error(t('Enter rider name'));
      if (r) await q(sb.from('riders').update(payload).eq('id', r.id));
      else await q(sb.from('riders').insert({ ...payload, status: 'offline' }));
      Modal.close(w); toast(t('Saved')); S.riders = await q(sb.from('riders').select('*').order('rider_code')); this.paint();
    }, { busy: ev.currentTarget });
  },
  async earnModal(r) {
    const since = addDays(new Date(), -30).toISOString();
    const rows = await q(sb.from('deliveries').select('*').eq('rider_id', r.id).gte('assigned_at', since).order('assigned_at', { ascending: false }));
    const done = rows.filter(d => d.status === 'delivered'), cancelled = rows.filter(d => d.status === 'cancelled'), failed = rows.filter(d => d.status === 'failed');
    const earn = done.length * num(r.per_ride_rate);
    const cashDue = done.reduce((s, d) => s + Math.max(0, num(d.cash_collected) - num(d.cash_submitted)), 0);
    const w = Modal.open({
      title: `${esc(r.name)} — ${esc(r.rider_code)}`, html: `
      <div class="stats"><div class="stat"><div class="v">${done.length}</div><div class="l">${t('Completed (30d)')}</div></div>
      <div class="stat"><div class="v">${cancelled.length}</div><div class="l">${t('Cancelled')}</div></div>
      <div class="stat"><div class="v">${failed.length}</div><div class="l">${t('Failed')}</div></div>
      <div class="stat"><div class="v">${money(earn)}</div><div class="l">${t('Ride Earnings')}</div></div></div>
      ${cashDue > 0 ? `<div class="banner row between"><span>${t('COD cash not yet submitted')}: <b>${money(cashDue)}</b></span><button class="btn sm ok" id="rc-submit">${t('Record cash submitted')}</button></div>` : ''}
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>${t('Date')}</th><th>${t('Status')}</th><th class="num">${t('COD')}</th><th class="num">${t('Collected')}</th><th class="num">${t('Submitted')}</th></tr></thead>
      <tbody>${done.map(d => `<tr><td>${fmtDT(d.delivered_at || d.assigned_at)}</td><td>${t(DSTATUS[d.status])}</td><td class="num">${money(d.cod_amount)}</td><td class="num">${money(d.cash_collected)}</td><td class="num">${money(d.cash_submitted)}</td></tr>`).join('') || `<tr><td colspan="5" class="center muted">${t('No deliveries')}</td></tr>`}</tbody></table></div>`
    });
    const sb2 = $('#rc-submit', w);
    if (sb2) sb2.onclick = () => safe(async () => {
      const v = await askText(t('Record cash submitted'), t('Amount (Rs.)'), { value: cashDue, type: 'number', ok: 'Save' }); if (v === null) return;
      const target = done.filter(d => num(d.cash_collected) > num(d.cash_submitted)).sort((a, b) => a.id - b.id)[0];
      if (!target) return;
      await rpc('submit_rider_cash', { p_delivery: target.id, p_amount: num(v) }); toast(t('Saved')); Modal.close(w); this.earnModal(r);
    }, { busy: sb2 });
  }
};

/* ---------- WAITERS / STAFF (management overview) ---------- */
VIEWS.waiters = {
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Waiters / Staff')}</h2></div><div class="rgrid" id="wt-grid"></div>
      <p class="sm muted mt">${t('New waiters sign up from the POS login screen and appear in Settings → Users to be activated with the Waiter role.')}</p>`;
    await this.paint();
  },
  refresh() { this.paint(); },
  async paint() {
    const since = startOfDay().toISOString();
    const withCounts = await Promise.all(S.waiters.map(async w => {
      const orders = await q(sb.from('orders').select('id, status').eq('waiter_id', w.id).gte('created_at', since));
      const cur = await q(sb.from('orders').select('order_no, tbl:dining_tables(code)').eq('waiter_id', w.id).in('status', ['accepted', 'preparing', 'ready']).limit(3));
      return { w, count: orders.length, cur };
    }));
    $('#wt-grid').innerHTML = withCounts.map(({ w, count, cur }) => `<div class="rcard ${w.waiter_status}">
      <div class="row"><span class="dot ${WDOT[w.waiter_status]}"></span><span class="rn grow">${esc(w.full_name)}</span><span class="rid">${esc(w.staff_id || '')}</span></div>
      <dl class="kv"><dt>${t("Today's Orders")}</dt><dd>${count}</dd><dt>${t('Status')}</dt><dd>${t(WSTATUS[w.waiter_status])}</dd></dl>
      ${cur.length ? `<div class="sm">🍽️ ${cur.map(o => `#${esc(o.order_no)}${o.tbl ? ' (' + esc(o.tbl.code) + ')' : ''}`).join(', ')}</div>` : `<div class="sm muted">${t('No active tables')}</div>`}
      <div class="acts row wrap">
        ${w.waiter_status !== 'inactive' ? `<button class="btn sm danger" data-wst="inactive" data-w="${w.id}">${t('Disable')}</button>` : `<button class="btn sm ok" data-wst="offline" data-w="${w.id}">${t('Enable')}</button>`}
      </div></div>`).join('') || `<div class="empty">${t('No waiters yet — add one in Settings → Users')}</div>`;
    $$('#wt-grid [data-wst]').forEach(b => b.onclick = () => safe(async () => { await rpc('set_waiter_status', { p_user: b.dataset.w, p_status: b.dataset.wst }); toast(t('Updated')); S.waiters = await q(sb.from('profiles').select('*').eq('role', 'waiter')); this.paint(); }, { busy: b }));
  }
};

/* ---------- MY TABLES (waiter role) ---------- */
VIEWS.mytables = {
  async render() {
    $('#view').innerHTML = `<div class="card mb" id="mt-status"></div>
      <div class="view-head"><h2>${t('My Tables')}</h2><button class="btn primary" id="mt-new">➕ ${t('New Order / POS')}</button></div>
      <div class="ogrid" id="mt-grid"></div>`;
    $('#mt-new').onclick = () => { S.cart = newCart(); location.hash = '#/pos'; };
    await this.load();
  },
  refresh() { this.load(); },
  async load() {
    const me = S.user;
    $('#mt-status').innerHTML = `<div class="row between"><div class="row"><span class="dot ${WDOT[me.waiter_status]}"></span><b>${esc(me.full_name)} — ${esc(me.staff_id || '')}</b></div>
      <div class="row">${me.waiter_status === 'offline' ? `<button class="btn sm ok" data-wst2="available">${t('Go Available')}</button>` : ''}${['available', 'serving'].includes(me.waiter_status) ? `<button class="btn sm ghost" data-wst2="offline">${t('Go Offline')}</button>` : ''}</div></div>`;
    $$('[data-wst2]').forEach(b => b.onclick = () => safe(async () => { await rpc('set_waiter_status', { p_user: me.id, p_status: b.dataset.wst2 }); me.waiter_status = b.dataset.wst2; this.load(); }));
    const rows = await q(sb.from('orders').select(OSEL).eq('waiter_id', me.id).in('status', OPEN_ST).order('created_at', { ascending: false }));
    $('#mt-grid').innerHTML = rows.length ? rows.map(o => orderCard(o)).join('') : `<div class="empty">${t('No active tables assigned to you')}</div>`;
  }
};

/* ---------- MY DELIVERIES (rider role) ---------- */
VIEWS.mydeliveries = {
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('My Deliveries')}</h2></div>
      <div class="card mb" id="md-status"></div>
      <div class="section-h">${t('DELIVERIES')}</div><div class="ogrid" id="md-active"></div>
      <div class="section-h">${t('Delivered today')}</div><div class="ogrid" id="md-done"></div>`;
    await this.load();
  },
  refresh() { this.load(); },
  async myRider() { if (!this._r) this._r = await q(sb.from('riders').select('*').eq('user_id', S.user.id).maybeSingle()); return this._r; },
  async load() {
    const r = await this.myRider();
    if (!r) { $('#md-status').innerHTML = `<div class="empty">${t('Ask the admin to link your account to a Rider profile')}</div>`; return; }
    $('#md-status').innerHTML = `<div class="row between"><div class="row"><span class="dot ${RDOT[r.status]}"></span><b>${esc(r.name)} — ${esc(r.rider_code)}</b></div>
      <div class="row">${r.status === 'available' ? `<button class="btn sm ghost" data-rst2="offline">${t('Go Offline')}</button>` : ''}${r.status === 'offline' ? `<button class="btn sm ok" data-rst2="available">${t('Go Available')}</button>` : ''}</div></div>`;
    $$('[data-rst2]').forEach(b => b.onclick = () => safe(async () => { await rpc('set_rider_status', { p_rider: r.id, p_status: b.dataset.rst2 }); toast(t('Updated')); this.load(); }));
    const dels = await q(sb.from('deliveries').select('*, orders(*, order_items(*), tbl:dining_tables(code))').eq('rider_id', r.id).in('status', ACTIVE_D).order('assigned_at'));
    $('#md-active').innerHTML = dels.length ? dels.map(d => this.card(d)).join('') : `<div class="empty">${t('No active delivery')}</div>`;
    const done = await q(sb.from('deliveries').select('*, orders(order_no, total, customer_name)').eq('rider_id', r.id).eq('status', 'delivered').gte('delivered_at', startOfDay().toISOString()).order('delivered_at', { ascending: false }));
    $('#md-done').innerHTML = done.length ? done.map(d => `<div class="ocard"><div class="oh"><span class="on">#${esc(d.orders.order_no)}</span><span class="pill ok">${t('Delivered')}</span></div><div class="om"><span>${esc(d.orders.customer_name || '')}</span><span class="display">${money(d.orders.total)}</span></div></div>`).join('') : `<div class="empty">${t('None yet today')}</div>`;
  },
  card(d) {
    const o = d.orders;
    return `<div class="ocard"><div class="oh"><span class="on">#${esc(o.order_no)}</span>${stPill(d.status)}</div>
      <div class="sm">👤 ${esc(o.customer_name || '')} · <a href="tel:${esc(o.phone)}">${esc(o.phone || '')}</a></div>
      <div class="sm">📍 ${esc(o.address || '')}</div><div class="items">${itemsLine(o)}</div>
      <div class="om"><span>${t('Total')}</span><span class="display">${money(o.total)}</span></div>
      <div class="acts">${deliveryActs(o)}</div></div>`;
  }
};

/* ---------- PAYMENTS ---------- */
VIEWS.payments = {
  range: 'today',
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Payments')}</h2>
      <select id="pv-range"><option value="today">${t('Today')}</option><option value="7">${t('Last 7 days')}</option><option value="30">${t('Last 30 days')}</option></select>
      <button class="btn sm ghost" id="pv-export">⬇ ${t('Export')}</button></div>
      <div class="stats mb" id="pv-stats"></div><div class="tbl-wrap"><table class="tbl" id="pv-tbl"></table></div>`;
    $('#pv-range').value = this.range;
    $('#pv-range').onchange = e => { this.range = e.target.value; this.load(); };
    $('#pv-export').onclick = () => this.export();
    this.load();
  },
  refresh() { this.load(); },
  since() { return this.range === 'today' ? startOfDay() : addDays(startOfDay(), -Number(this.range)); },
  async load() {
    this.rows = await q(sb.from('payments').select('*, orders(order_no, source, fulfillment)').gte('created_at', this.since().toISOString()).order('created_at', { ascending: false }));
    const total = this.rows.reduce((s, p) => s + num(p.amount), 0);
    const byM = {}; this.rows.forEach(p => byM[p.method] = (byM[p.method] || 0) + num(p.amount));
    $('#pv-stats').innerHTML = `<div class="stat hero"><div class="v">${money(total)}</div><div class="l">${t('Total Received')}</div></div>` + Object.entries(byM).map(([m, v]) => `<div class="stat"><div class="v">${money(v)}</div><div class="l">${esc(m)}</div></div>`).join('');
    $('#pv-tbl').innerHTML = `<thead><tr><th>${t('Time')}</th><th>${t('Order')}</th><th>${t('Method')}</th><th class="num">${t('Amount')}</th></tr></thead>
      <tbody>${this.rows.map(p => `<tr class="click" data-act="view" data-id="${p.order_id}"><td>${fmtDT(p.created_at)}</td><td>#${esc(p.orders?.order_no || '')}</td><td>${esc(p.method)}</td><td class="num">${money(p.amount)}</td></tr>`).join('') || `<tr><td colspan="4" class="center muted">${t('No payments')}</td></tr>`}</tbody>`;
  },
  export() { downloadCSV('payments', [{ label: 'Time', get: r => fmtDT(r.created_at) }, { label: 'Order', get: r => r.orders?.order_no }, { label: 'Method', key: 'method' }, { label: 'Amount', key: 'amount' }], this.rows || []); }
};

/* ---------- CUSTOMERS ---------- */
VIEWS.customers = {
  q: '',
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Customers')}</h2></div>
      <input id="cu-q" placeholder="${t('Search name, phone or order number')}" class="mb" style="max-width:340px">
      <div class="tbl-wrap"><table class="tbl" id="cu-tbl"></table></div>`;
    $('#cu-q').oninput = debounce(e => { this.q = e.target.value; this.load(); }, 300);
    this.load();
  },
  refresh() { this.load(); },
  async load() {
    let rows;
    if (this.q && /^YM-/i.test(this.q.trim())) {
      const os = await q(sb.from('orders').select('customer_id').ilike('order_no', this.q.trim()).limit(1));
      const cid = os[0] && os[0].customer_id;
      rows = cid ? await q(sb.from('customers').select('*').eq('id', cid)) : [];
    } else {
      let qy = sb.from('customers').select('*').order('updated_at', { ascending: false }).limit(100);
      if (this.q) qy = qy.or(`name.ilike.%${this.q}%,phone.ilike.%${this.q}%`);
      rows = await q(qy);
    }
    $('#cu-tbl').innerHTML = `<thead><tr><th>${t('Name')}</th><th>${t('Phone')}</th><th>${t('Address')}</th><th>${t('Notes')}</th></tr></thead>
      <tbody>${rows.map(c => `<tr class="click" data-cu="${c.id}"><td>${esc(c.name || '—')}</td><td>${esc(c.phone || '—')}</td><td>${esc(c.address || '—')}</td><td>${esc(c.notes || '')}</td></tr>`).join('') || `<tr><td colspan="4" class="center muted">${t('No customers found')}</td></tr>`}</tbody>`;
    $$('#cu-tbl [data-cu]').forEach(tr => tr.onclick = () => this.open(+tr.dataset.cu));
  },
  async open(id) {
    const c = await q(sb.from('customers').select('*').eq('id', id).single());
    const orders = await q(sb.from('orders').select('id, order_no, created_at, total, status').eq('customer_id', id).order('created_at', { ascending: false }).limit(20));
    Modal.open({
      title: c.name || c.phone, html: `<div class="card"><div>📞 ${esc(c.phone || '—')}</div><div>📍 ${esc(c.address || '—')}</div>${c.notes ? `<div>📝 ${esc(c.notes)}</div>` : ''}</div>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>${t('Order')}</th><th>${t('Date')}</th><th>${t('Status')}</th><th class="num">${t('Total')}</th></tr></thead>
      <tbody>${orders.map(o => `<tr class="click" data-act="view" data-id="${o.id}" data-closes="1"><td>#${esc(o.order_no)}</td><td>${fmtDT(o.created_at)}</td><td>${stPill(o.status)}</td><td class="num">${money(o.total)}</td></tr>`).join('') || `<tr><td colspan="4" class="center muted">${t('No orders yet')}</td></tr>`}</tbody></table></div>`
    });
  }
};

/* ---------- REPORTS ---------- */
VIEWS.reports = {
  tab: 'sales', range: 'today',
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Reports')}</h2>
      <select id="rp-range"><option value="today">${t('Today')}</option><option value="7">${t('Last 7 days')}</option><option value="30">${t('Last 30 days')}</option></select></div>
      <div class="tabs" id="rp-tabs">${[['sales', 'Daily Sales'], ['orders', 'Daily Orders'], ['payment', 'Payment'], ['online', 'Online Orders'], ['manual', 'Manual Orders'], ['delivery', 'Delivery'], ['rider', 'Rider Delivery'], ['waiter', 'Waiter'], ['cancelled', 'Cancelled']].map(([k, l]) => `<button class="tab ${this.tab === k ? 'on' : ''}" data-t="${k}">${t(l)}</button>`).join('')}</div>
      <div id="rp-body"></div>`;
    $('#rp-range').value = this.range; $('#rp-range').onchange = e => { this.range = e.target.value; this.load(); };
    $$('#rp-tabs .tab').forEach(b => b.onclick = () => { this.tab = b.dataset.t; this.render(); });
    this.load();
  },
  refresh() { this.load(); },
  since() { return this.range === 'today' ? startOfDay() : addDays(startOfDay(), -Number(this.range)); },
  async load() {
    const body = $('#rp-body'); body.innerHTML = `<div class="empty">${t('Loading')}…</div>`;
    const since = this.since().toISOString();
    const orders = await q(sb.from('orders').select('*').gte('created_at', since));
    const done = orders.filter(o => ['completed', 'delivered'].includes(o.status));
    const cancelled = orders.filter(o => ['cancelled', 'rejected'].includes(o.status));
    const head = `<div class="row end mb"><button class="btn sm ghost" id="rp-print">🖨 ${t('Print')}</button><button class="btn sm ghost" id="rp-csv">⬇ ${t('Export')}</button></div>`;
    let rows, cols, tableHTML, title = this.tab;
    if (this.tab === 'sales') {
      const days = {}; done.forEach(o => { const k = isoDate(o.created_at); days[k] = (days[k] || 0) + num(o.total); });
      rows = Object.entries(days).sort((a, b) => b[0].localeCompare(a[0])).map(([d, v]) => ({ date: d, total: v }));
      cols = [{ label: 'Date', key: 'date' }, { label: 'Sales', get: r => money(r.total) }];
      title = 'Daily Sales Report';
    } else if (this.tab === 'orders') {
      rows = orders.map(o => ({ order_no: o.order_no, date: fmtDT(o.created_at), source: t(SRC[o.source]), status: t(STATUS[o.status]), total: money(o.total) }));
      cols = [{ label: 'Order', key: 'order_no' }, { label: 'Date', key: 'date' }, { label: 'Source', key: 'source' }, { label: 'Status', key: 'status' }, { label: 'Total', key: 'total' }];
      title = 'Daily Order Report';
    } else if (this.tab === 'payment') {
      const pays = await q(sb.from('payments').select('*, orders(order_no)').gte('created_at', since));
      rows = pays.map(p => ({ order: p.orders?.order_no, method: p.method, date: fmtDT(p.created_at), amount: money(p.amount) }));
      cols = [{ label: 'Order', key: 'order' }, { label: 'Method', key: 'method' }, { label: 'Date', key: 'date' }, { label: 'Amount', key: 'amount' }];
      title = 'Payment Report';
    } else if (this.tab === 'online') {
      rows = orders.filter(o => isOnlineSrc(o.source)).map(o => ({ order_no: o.order_no, date: fmtDT(o.created_at), status: t(STATUS[o.status]), total: money(o.total) }));
      cols = [{ label: 'Order', key: 'order_no' }, { label: 'Date', key: 'date' }, { label: 'Status', key: 'status' }, { label: 'Total', key: 'total' }];
      title = 'Online Order Report';
    } else if (this.tab === 'manual') {
      rows = orders.filter(o => !isOnlineSrc(o.source)).map(o => ({ order_no: o.order_no, date: fmtDT(o.created_at), source: t(SRC[o.source]), total: money(o.total) }));
      cols = [{ label: 'Order', key: 'order_no' }, { label: 'Date', key: 'date' }, { label: 'Source', key: 'source' }, { label: 'Total', key: 'total' }];
      title = 'Manual Order Report';
    } else if (this.tab === 'delivery') {
      rows = orders.filter(o => o.fulfillment === 'delivery').map(o => ({ order_no: o.order_no, date: fmtDT(o.created_at), status: t(STATUS[o.status]), address: o.address, total: money(o.total) }));
      cols = [{ label: 'Order', key: 'order_no' }, { label: 'Date', key: 'date' }, { label: 'Status', key: 'status' }, { label: 'Address', key: 'address' }, { label: 'Total', key: 'total' }];
      title = 'Delivery Report';
    } else if (this.tab === 'rider') {
      const dels = await q(sb.from('deliveries').select('*, riders(name, rider_code), orders(order_no,total)').gte('assigned_at', since));
      rows = dels.map(d => ({ rider: `${d.riders?.name} (${d.riders?.rider_code})`, order: d.orders?.order_no, status: t(DSTATUS[d.status]), date: fmtDT(d.assigned_at), amount: money(d.orders?.total) }));
      cols = [{ label: 'Rider', key: 'rider' }, { label: 'Order', key: 'order' }, { label: 'Status', key: 'status' }, { label: 'Date', key: 'date' }, { label: 'Amount', key: 'amount' }];
      title = 'Rider Delivery Report';
    } else if (this.tab === 'waiter') {
      const wOrders = await q(sb.from('orders').select('*, waiter:profiles!waiter_id(full_name, staff_id), tbl:dining_tables(code)').eq('fulfillment', 'dinein').not('waiter_id', 'is', null).gte('created_at', since));
      rows = wOrders.map(o => ({ waiter: `${o.waiter?.full_name || ''} (${o.waiter?.staff_id || ''})`, order: o.order_no, table: o.tbl?.code || '', status: t(STATUS[o.status]), date: fmtDT(o.created_at), total: money(o.total) }));
      cols = [{ label: 'Waiter', key: 'waiter' }, { label: 'Order', key: 'order' }, { label: 'Table', key: 'table' }, { label: 'Status', key: 'status' }, { label: 'Date', key: 'date' }, { label: 'Total', key: 'total' }];
      title = 'Waiter Report';
    } else {
      rows = cancelled.map(o => ({ order_no: o.order_no, date: fmtDT(o.created_at), status: t(STATUS[o.status]), reason: o.cancel_reason || '', total: money(o.total) }));
      cols = [{ label: 'Order', key: 'order_no' }, { label: 'Date', key: 'date' }, { label: 'Status', key: 'status' }, { label: 'Reason', key: 'reason' }, { label: 'Total', key: 'total' }];
      title = 'Cancelled Order Report';
    }
    this._rows = rows; this._cols = cols; this._title = title;
    tableHTML = `<table class="tbl"><thead><tr>${cols.map(c => `<th>${t(c.label)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(c => `<td>${esc(c.get ? c.get(r) : r[c.key])}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${cols.length}" class="center muted">${t('No data')}</td></tr>`}</tbody></table>`;
    body.innerHTML = head + `<div class="tbl-wrap">${tableHTML}</div>`;
    $('#rp-print').onclick = () => printHTML(t(title), tableHTML);
    $('#rp-csv').onclick = () => downloadCSV(this.tab, cols, rows);
  }
};

/* ---------- SETTINGS ---------- */
VIEWS.settings = {
  async render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('POS Settings')}</h2></div>
      <div class="tabs" id="st-tabs"><button class="tab on" data-t="general">${t('General')}</button><button class="tab" data-t="tables">${t('Tables')}</button><button class="tab" data-t="menu">${t('Menu availability')}</button>${S.role === 'super_admin' ? `<button class="tab" data-t="users">${t('Users')}</button>` : ''}</div>
      <div id="st-body"></div>`;
    $$('#st-tabs .tab').forEach(b => b.onclick = () => { $$('#st-tabs .tab').forEach(x => x.classList.toggle('on', x === b)); this.paint(b.dataset.t); });
    this.paint('general');
  },
  refresh() {},
  async paint(tabId) {
    const body = $('#st-body');
    if (tabId === 'general') {
      body.innerHTML = settingsFormHTML(S.settings, S.role === 'super_admin');
      $('#s-save').onclick = ev => safe(async () => { await saveSettingsForm(S.settings, S.role === 'super_admin'); S.settings = await loadSettings(); toast(t('Settings saved')); }, { busy: ev.currentTarget });
    } else if (tabId === 'tables') {
      body.innerHTML = `<div class="row mb"><input id="tb-new" placeholder="${t('New table code e.g. T09')}" style="max-width:200px"><button class="btn primary" id="tb-add">${t('Add Table')}</button></div>
        <div class="tgrid">${S.tables.map(tb => `<div class="tcard ${tb.status}"><span class="tc">${esc(tb.code)}</span><span class="st">${t({ available: 'AVAILABLE', occupied: 'OCCUPIED', reserved: 'RESERVED' }[tb.status])}</span><span class="sm muted">${tb.seats} ${t('seats')}</span>
          ${tb.status !== 'occupied' ? `<button class="btn sm ghost" data-tres="${tb.id}" data-cur="${tb.status}">${t(tb.status === 'reserved' ? 'Unreserve' : 'Reserve')}</button>` : ''}</div>`).join('')}</div>`;
      $('#tb-add').onclick = ev => safe(async () => {
        const code = $('#tb-new').value.trim().toUpperCase(); if (!code) return;
        await q(sb.from('dining_tables').insert({ code, seats: 4 })); S.tables = await q(sb.from('dining_tables').select('*').order('code')); this.paint('tables'); toast(t('Table added'));
      }, { busy: ev.currentTarget });
      $$('[data-tres]').forEach(b => b.onclick = () => safe(async () => { await rpc('set_table_status', { p_table: +b.dataset.tres, p_status: b.dataset.cur === 'reserved' ? 'available' : 'reserved' }); toast(t('Updated')); }));
    } else if (tabId === 'menu') {
      body.innerHTML = `<div class="prod-grid">${S.products.map(p => `<div class="pcard ${p.is_available ? '' : 'off'}" style="pointer-events:auto;cursor:default">
        <div class="ph">${catEmoji((S.cats.find(c => c.id === p.category_id) || {}).name)}</div>
        <div class="pi"><div class="pn">${esc(pick(p))}</div><label class="row sm"><input type="checkbox" data-avail="${p.id}" ${p.is_available ? 'checked' : ''}> ${t('Available')}</label></div></div>`).join('')}</div>`;
      $$('[data-avail]').forEach(cb => cb.onchange = () => safe(() => rpc('set_product_available', { p_product: +cb.dataset.avail, p_flag: cb.checked })));
    } else if (tabId === 'users') {
      const users = await q(sb.from('profiles').select('*').order('created_at'));
      body.innerHTML = `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>${t('Name')}</th><th>${t('Username')}</th><th>${t('Role')}</th><th>${t('Status')}</th><th></th></tr></thead>
        <tbody>${users.map(u => `<tr><td>${esc(u.full_name)}</td><td>${esc(u.username)}</td>
        <td><select data-urole="${u.id}" ${u.id === S.user.id ? 'disabled' : ''}>${Object.keys(ROLE_LABEL).map(r => `<option value="${r}" ${u.role === r ? 'selected' : ''}>${t(ROLE_LABEL[r])}</option>`).join('')}</select></td>
        <td><label class="row sm"><input type="checkbox" data-uactive="${u.id}" ${u.is_active ? 'checked' : ''} ${u.id === S.user.id ? 'disabled' : ''}> ${t('Active')}</label></td>
        <td><button class="btn sm ghost" data-upass="${u.id}">${t('Set Password')}</button></td></tr>`).join('')}</tbody></table></div>
        <p class="sm muted mt">${t('New staff sign up on the login screen with a username and password, then appear here to be activated.')}</p>`;
      $$('[data-urole]').forEach(s => s.onchange = () => safe(() => q(sb.from('profiles').update({ role: s.value }).eq('id', s.dataset.urole))));
      $$('[data-uactive]').forEach(cb => cb.onchange = () => safe(() => q(sb.from('profiles').update({ is_active: cb.checked }).eq('id', cb.dataset.uactive))));
      $$('[data-upass]').forEach(b => b.onclick = () => safe(async () => { const p = await askText(t('Set Password'), t('New password / PIN (min 6 chars)'), { type: 'password' }); if (!p) return; await rpc('admin_set_password', { p_user: b.dataset.upass, p_password: p }); toast(t('Password updated')); }));
    }
  }
};
