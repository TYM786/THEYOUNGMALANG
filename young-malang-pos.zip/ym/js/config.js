/* ===================================================================
   THE YOUNG MALANG — settings you edit ONCE
   Supabase Dashboard -> Project Settings -> API
   (the anon / public key is safe to keep in the browser; access is
    protected by the Row Level Security rules in supabase/schema.sql)
   =================================================================== */
window.YM_CONFIG = {
  SUPABASE_URL: 'https://pmmmnslhseewneswitqa.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_RSPiyMVbHFsU5-_V5MmPKA_GoQdlbl1',

  // Staff type just a username (e.g. "ali"). Behind the scenes it becomes ali@staff.youngmalang.com
  USERNAME_DOMAIN: 'staff.youngmalang.com',

  BRAND: {
    name: 'THE YOUNG MALANG',
    tagline: 'Pizza & Burger',
    phones: ['0349-8190030', '0337-1111475'],
    address: 'Near Rajput Marriage Hall, Sardar Market',
    logo: 'assets/logo.jpg',
    currency: 'Rs.'
  }
};
