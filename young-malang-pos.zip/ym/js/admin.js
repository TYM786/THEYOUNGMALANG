/* =====================================================================
   THE YOUNG MALANG — ADMIN / MANAGEMENT PANEL
   ===================================================================== */
const A = { role: '', settings: {}, cats: [], products: [], variants: [], addons: [], incentives: [], view: '' };
const ANAV = [
  ['menu', '🍽️', 'Menu & Categories'],
  ['tables', '🍽️', 'Tables'],
  ['riders', '🏍️', 'Riders & Incentives'],
  ['users', '👥', 'Users & Roles'],
  ['settings', '⚙️', 'Business Settings']
];

Shell.init({
  loginTitle: 'Admin Login', roles: ['super_admin', 'manager'],
  onReady: async prof => {
    A.role = prof.role;
    await loadAll();
    buildSidebar();
    window.addEventListener('hashchange', route);
    Live.start(['products', 'categories', 'product_variants', 'addons', 'riders', 'dining_tables', 'settings', 'profiles'], () => { debounce(refresh, 400)(); });
    route();
  },
  onLang: () => { buildSidebar(); route(true); }
});

async function loadAll() {
  const [cats, prods, vars, adds, tbls, riders, incent, settings] = await Promise.all([
    q(sb.from('categories').select('*').order('sort')),
    q(sb.from('products').select('*').order('sort')),
    q(sb.from('product_variants').select('*').order('sort')),
    q(sb.from('addons').select('*').order('id')),
    q(sb.from('dining_tables').select('*').order('code')),
    q(sb.from('riders').select('*').order('rider_code')),
    q(sb.from('rider_incentives').select('*').order('id')),
    loadSettings()
  ]);
  Object.assign(A, { cats, products: prods, variants: vars, addons: adds, tables: tbls, riders, incentives: incent, settings });
}
async function refresh() { await loadAll(); const v = VIEWS[A.view]; if (v) v.render(); }

function buildSidebar() {
  $('#sidebar').innerHTML = `${logoHTML(70)}<div class="pill" style="align-self:center;margin-bottom:8px">${t('ADMIN PANEL')}</div>
    ${ANAV.map(([id, ic, l]) => `<button class="nav-item ${A.view === id ? 'on' : ''}" data-nav="${id}"><span class="ic">${ic}</span><span>${t(l)}</span></button>`).join('')}
    <a class="nav-item" href="index.html" target="_blank"><span class="ic">🖥️</span><span>${t('Open POS')}</span></a>
    <div class="nav-sep"></div><button class="nav-item" data-act="logout"><span class="ic">⎋</span><span>${t('Logout')}</span></button>`;
}
document.addEventListener('click', e => { const n = e.target.closest('[data-nav]'); if (n) location.hash = '#/' + n.dataset.nav; });
document.addEventListener('click', e => { const b = e.target.closest('[data-act="logout"]'); if (b) Shell.logout(); });
$('#topbar') && ($('#topbar').innerHTML = $('#topbar').innerHTML); // noop, drawn by Shell

const VIEWS = {};
function route(force) {
  let v = location.hash.replace('#/', '');
  if (!ANAV.some(n => n[0] === v)) v = 'menu';
  if (v === A.view && !force) return;
  A.view = v; buildSidebar();
  Shell.title(t((ANAV.find(n => n[0] === v) || [])[2] || ''));
  $('#view').innerHTML = ''; VIEWS[v].render();
}

/* ---------- MENU & CATEGORIES ---------- */
VIEWS.menu = {
  cat: null,
  render() {
    this.cat = this.cat || (A.cats[0] && A.cats[0].id) || null;
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Menu & Categories')}</h2><button class="btn primary" id="mn-addcat">➕ ${t('Add Category')}</button></div>
      <div class="tabs" id="mn-cats"></div>
      <div class="view-head"><h3 style="margin-inline-end:auto">${t('Products')}</h3><button class="btn" id="mn-addprod">➕ ${t('Add Product')}</button></div>
      <div class="tbl-wrap"><table class="tbl" id="mn-prods"></table></div>`;
    this.paintCats(); this.paintProds();
    $('#mn-addcat').onclick = () => this.catModal();
    $('#mn-addprod').onclick = () => this.prodModal();
  },
  paintCats() {
    $('#mn-cats').innerHTML = A.cats.map(c => `<button class="tab ${c.id === this.cat ? 'on' : ''}" data-c="${c.id}">${catEmoji(c.name)} ${esc(pick(c))} <span class="n">${A.products.filter(p => p.category_id === c.id).length}</span></button>`).join('') + `<button class="tab ghost" id="mn-editcat">✎ ${t('Edit')}</button>`;
    $$('#mn-cats [data-c]').forEach(b => b.onclick = () => { this.cat = +b.dataset.c; this.render(); });
    $('#mn-editcat').onclick = () => this.catModal(A.cats.find(c => c.id === this.cat));
  },
  paintProds() {
    const list = A.products.filter(p => p.category_id === this.cat);
    $('#mn-prods').innerHTML = `<thead><tr><th>${t('Name')}</th><th>${t('Price')}</th><th>${t('Sizes')}</th><th>${t('Available')}</th><th></th></tr></thead>
      <tbody>${list.map(p => `<tr><td>${esc(pick(p))}</td><td>${A.variants.some(v => v.product_id === p.id) ? t('Varies') : money(p.price)}</td>
        <td>${A.variants.filter(v => v.product_id === p.id).map(v => esc(pick(v))).join(', ') || '—'}</td>
        <td><input type="checkbox" data-pav="${p.id}" ${p.is_available ? 'checked' : ''}></td>
        <td class="row"><button class="btn sm ghost" data-pedit="${p.id}">${t('Edit')}</button><button class="btn sm danger" data-pdel="${p.id}">${t('Delete')}</button></td></tr>`).join('') || `<tr><td colspan="5" class="center muted">${t('No products in this category')}</td></tr>`}</tbody>`;
    $$('[data-pav]').forEach(cb => cb.onchange = () => safe(() => q(sb.from('products').update({ is_available: cb.checked }).eq('id', cb.dataset.pav))));
    $$('[data-pedit]').forEach(b => b.onclick = () => this.prodModal(A.products.find(p => p.id === +b.dataset.pedit)));
    $$('[data-pdel]').forEach(b => b.onclick = () => safe(async () => { if (!await confirmBox(t('Delete this product? This cannot be undone.'), { danger: true })) return; await q(sb.from('products').delete().eq('id', b.dataset.pdel)); toast(t('Deleted')); refresh(); }));
  },
  catModal(c) {
    const w = Modal.open({
      title: t(c ? 'Edit Category' : 'Add Category'), html: `<div class="form-grid">
      <label class="f">${t('Name (English)')}<input id="c-name" value="${esc(c?.name || '')}"></label>
      <label class="f">${t('Name (Urdu)')}<input id="c-nameur" value="${esc(c?.name_ur || '')}" dir="rtl"></label>
      <label class="f">${t('Sort order')}<input id="c-sort" type="number" value="${c?.sort ?? A.cats.length + 1}"></label></div>
      <div class="row wrap">${c ? `<button class="btn danger" id="c-del">${t('Delete Category')}</button>` : ''}<button class="btn primary grow" id="c-save">${t('Save')}</button></div>`
    });
    $('#c-save', w).onclick = ev => safe(async () => {
      const p = { name: $('#c-name', w).value.trim(), name_ur: $('#c-nameur', w).value.trim() || null, sort: num($('#c-sort', w).value) };
      if (!p.name) throw new Error(t('Enter category name'));
      if (c) await q(sb.from('categories').update(p).eq('id', c.id)); else await q(sb.from('categories').insert(p));
      Modal.close(w); toast(t('Saved')); refresh();
    }, { busy: ev.currentTarget });
    if (c) $('#c-del', w).onclick = () => safe(async () => {
      if (!await confirmBox(t('Delete this category and unlink its products?'), { danger: true })) return;
      await q(sb.from('categories').delete().eq('id', c.id)); Modal.close(w); toast(t('Deleted')); this.cat = null; refresh();
    });
  },
  prodModal(p) {
    const vars = p ? A.variants.filter(v => v.product_id === p.id).sort((a, b) => a.sort - b.sort) : [];
    let varRows = vars.map(v => ({ ...v }));
    const w = Modal.open({
      title: t(p ? 'Edit Product' : 'Add Product'), wide: true, html: `<div class="form-grid">
      <label class="f">${t('Category')}<select id="p-cat">${A.cats.map(c => `<option value="${c.id}" ${p?.category_id === c.id || (!p && this.cat === c.id) ? 'selected' : ''}>${esc(pick(c))}</option>`).join('')}</select></label>
      <label class="f">${t('Sort order')}<input id="p-sort" type="number" value="${p?.sort ?? 1}"></label>
      <label class="f">${t('Name (English)')}<input id="p-name" value="${esc(p?.name || '')}"></label>
      <label class="f">${t('Name (Urdu)')}<input id="p-nameur" value="${esc(p?.name_ur || '')}" dir="rtl"></label>
      <label class="f full">${t('Description')}<input id="p-desc" value="${esc(p?.description || '')}"></label>
      <label class="f">${t('Base Price (Rs.)')} <span class="sm muted">(${t('ignored if sizes are added below')})</span><input id="p-price" type="number" value="${p?.price ?? 0}"></label>
      <label class="f">${t('Image URL')}<input id="p-img" value="${esc(p?.image_url || '')}" placeholder="https://…"></label></div>
      <div class="muted b sm mt">${t('Sizes / Variants')} <span class="sm">(${t('leave empty for single-price item')})</span></div>
      <div id="p-vars"></div><button type="button" class="btn sm ghost" id="p-addvar">➕ ${t('Add Size')}</button>
      <div class="row wrap mt2">${p ? `<button class="btn danger" id="p-del">${t('Delete Product')}</button>` : ''}<button class="btn primary grow" id="p-save">${t('Save Product')}</button></div>`
    });
    const paintVars = () => {
      $('#p-vars', w).innerHTML = varRows.map((v, i) => `<div class="row" style="margin-bottom:6px">
        <input placeholder="${t('Size name e.g. Large')}" value="${esc(v.name || '')}" data-vn="${i}" style="flex:2">
        <input placeholder="${t('Urdu')}" value="${esc(v.name_ur || '')}" dir="rtl" data-vnu="${i}" style="flex:1">
        <input type="number" placeholder="${t('Price')}" value="${v.price ?? ''}" data-vp="${i}" style="flex:1">
        <button type="button" class="icon-btn" data-vrm="${i}">🗑</button></div>`).join('');
      $$('[data-vn]', w).forEach(inp => inp.oninput = () => varRows[+inp.dataset.vn].name = inp.value);
      $$('[data-vnu]', w).forEach(inp => inp.oninput = () => varRows[+inp.dataset.vnu].name_ur = inp.value);
      $$('[data-vp]', w).forEach(inp => inp.oninput = () => varRows[+inp.dataset.vp].price = num(inp.value));
      $$('[data-vrm]', w).forEach(b => b.onclick = () => { varRows.splice(+b.dataset.vrm, 1); paintVars(); });
    };
    paintVars();
    $('#p-addvar', w).onclick = () => { varRows.push({ name: '', name_ur: '', price: 0 }); paintVars(); };
    $('#p-save', w).onclick = ev => safe(async () => {
      const payload = { category_id: +$('#p-cat', w).value, sort: num($('#p-sort', w).value), name: $('#p-name', w).value.trim(), name_ur: $('#p-nameur', w).value.trim() || null, description: $('#p-desc', w).value.trim() || null, price: num($('#p-price', w).value), image_url: $('#p-img', w).value.trim() || null };
      if (!payload.name) throw new Error(t('Enter product name'));
      let pid = p?.id;
      if (p) await q(sb.from('products').update(payload).eq('id', p.id));
      else { const [row] = await q(sb.from('products').insert(payload).select()); pid = row.id; }
      await q(sb.from('product_variants').delete().eq('product_id', pid));
      const goodVars = varRows.filter(v => v.name && v.name.trim());
      if (goodVars.length) await q(sb.from('product_variants').insert(goodVars.map((v, i) => ({ product_id: pid, name: v.name.trim(), name_ur: v.name_ur || null, price: num(v.price), sort: i }))));
      Modal.close(w); toast(t('Saved')); refresh();
    }, { busy: ev.currentTarget });
    if (p) $('#p-del', w).onclick = () => safe(async () => { if (!await confirmBox(t('Delete this product?'), { danger: true })) return; await q(sb.from('products').delete().eq('id', p.id)); Modal.close(w); toast(t('Deleted')); refresh(); });
  }
};

/* ---------- ADD-ONS (shown inside menu view as a second block) ---------- */
const _menuRender = VIEWS.menu.render.bind(VIEWS.menu);
VIEWS.menu.render = function () {
  _menuRender();
  $('#view').insertAdjacentHTML('beforeend', `<div class="view-head mt2"><h3 style="margin-inline-end:auto">${t('Add-ons')}</h3><button class="btn" id="mn-addon">➕ ${t('Add Add-on')}</button></div><div class="tbl-wrap"><table class="tbl" id="mn-addons"></table></div>`);
  this.paintAddons();
  $('#mn-addon').onclick = () => this.addonModal();
};
VIEWS.menu.paintAddons = function () {
  $('#mn-addons').innerHTML = `<thead><tr><th>${t('Name')}</th><th>${t('Category')}</th><th class="num">${t('Price')}</th><th>${t('Active')}</th><th></th></tr></thead>
    <tbody>${A.addons.map(a => `<tr><td>${esc(pick(a))}</td><td>${a.category_id ? esc(pick(A.cats.find(c => c.id === a.category_id) || {})) : t('All categories')}</td><td class="num">${money(a.price)}</td>
    <td><input type="checkbox" data-aav="${a.id}" ${a.is_active ? 'checked' : ''}></td><td class="row"><button class="btn sm ghost" data-aedit="${a.id}">${t('Edit')}</button><button class="btn sm danger" data-adel="${a.id}">${t('Delete')}</button></td></tr>`).join('') || `<tr><td colspan="5" class="center muted">${t('No add-ons yet')}</td></tr>`}</tbody>`;
  $$('[data-aav]').forEach(cb => cb.onchange = () => safe(() => q(sb.from('addons').update({ is_active: cb.checked }).eq('id', cb.dataset.aav))));
  $$('[data-aedit]').forEach(b => b.onclick = () => this.addonModal(A.addons.find(a => a.id === +b.dataset.aedit)));
  $$('[data-adel]').forEach(b => b.onclick = () => safe(async () => { if (!await confirmBox(t('Delete this add-on?'), { danger: true })) return; await q(sb.from('addons').delete().eq('id', b.dataset.adel)); toast(t('Deleted')); refresh(); }));
};
VIEWS.menu.addonModal = function (a) {
  const w = Modal.open({
    title: t(a ? 'Edit Add-on' : 'Add Add-on'), html: `<div class="form-grid">
    <label class="f">${t('Name (English)')}<input id="a-name" value="${esc(a?.name || '')}"></label>
    <label class="f">${t('Name (Urdu)')}<input id="a-nameur" value="${esc(a?.name_ur || '')}" dir="rtl"></label>
    <label class="f">${t('Price (Rs.)')}<input id="a-price" type="number" value="${a?.price ?? 0}"></label>
    <label class="f">${t('Applies to')}<select id="a-cat"><option value="">${t('All categories')}</option>${A.cats.map(c => `<option value="${c.id}" ${a?.category_id === c.id ? 'selected' : ''}>${esc(pick(c))}</option>`).join('')}</select></label></div>
    <div class="row wrap">${a ? `<button class="btn danger" id="a-del">${t('Delete')}</button>` : ''}<button class="btn primary grow" id="a-save">${t('Save')}</button></div>`
  });
  $('#a-save', w).onclick = ev => safe(async () => {
    const p = { name: $('#a-name', w).value.trim(), name_ur: $('#a-nameur', w).value.trim() || null, price: num($('#a-price', w).value), category_id: $('#a-cat', w).value ? +$('#a-cat', w).value : null };
    if (!p.name) throw new Error(t('Enter add-on name'));
    if (a) await q(sb.from('addons').update(p).eq('id', a.id)); else await q(sb.from('addons').insert(p));
    Modal.close(w); toast(t('Saved')); refresh();
  }, { busy: ev.currentTarget });
  if (a) $('#a-del', w).onclick = () => safe(async () => { if (!await confirmBox(t('Delete this add-on?'), { danger: true })) return; await q(sb.from('addons').delete().eq('id', a.id)); Modal.close(w); toast(t('Deleted')); refresh(); });
};

/* ---------- TABLES ---------- */
VIEWS.tables = {
  render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Tables')}</h2><div class="row"><input id="tb-code" placeholder="${t('e.g. T09')}" style="width:120px"><input id="tb-seats" type="number" placeholder="${t('Seats')}" value="4" style="width:90px"><button class="btn primary" id="tb-add">➕ ${t('Add Table')}</button></div></div>
      <div class="tgrid" id="tb-grid"></div>`;
    this.paint();
    $('#tb-add').onclick = ev => safe(async () => {
      const code = $('#tb-code').value.trim().toUpperCase(); if (!code) throw new Error(t('Enter table code'));
      await q(sb.from('dining_tables').insert({ code, seats: num($('#tb-seats').value) || 4 })); toast(t('Table added')); refresh();
    }, { busy: ev.currentTarget });
  },
  paint() {
    $('#tb-grid').innerHTML = A.tables.map(tb => `<div class="tcard ${tb.status}"><span class="tc">${esc(tb.code)}</span><span class="st">${t({ available: 'AVAILABLE', occupied: 'OCCUPIED', reserved: 'RESERVED' }[tb.status])}</span>
      <span class="sm muted">${tb.seats} ${t('seats')} · ${esc(tb.qr_code)}</span>
      ${tb.status !== 'occupied' ? `<button class="btn sm danger" data-tdel="${tb.id}">${t('Delete')}</button>` : ''}</div>`).join('');
    $$('[data-tdel]').forEach(b => b.onclick = () => safe(async () => { if (!await confirmBox(t('Delete this table?'), { danger: true })) return; await q(sb.from('dining_tables').delete().eq('id', b.dataset.tdel)); toast(t('Deleted')); refresh(); }));
  }
};

/* ---------- RIDERS & INCENTIVES ---------- */
VIEWS.riders = {
  render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Riders & Incentives')}</h2><button class="btn primary" id="rd-add">➕ ${t('Add Rider')}</button></div>
      <div class="tbl-wrap"><table class="tbl" id="rd-tbl"></table></div>
      <div class="view-head mt2"><h3 style="margin-inline-end:auto">${t('Incentive Rules')}</h3><button class="btn" id="in-add">➕ ${t('Add Rule')}</button></div>
      <div class="tbl-wrap"><table class="tbl" id="in-tbl"></table></div>`;
    this.paintRiders(); this.paintIncent();
    $('#rd-add').onclick = () => this.riderModal();
    $('#in-add').onclick = () => this.incentModal();
  },
  paintRiders() {
    $('#rd-tbl').innerHTML = `<thead><tr><th>${t('Rider ID')}</th><th>${t('Name')}</th><th>${t('Phone')}</th><th>${t('Vehicle')}</th><th>${t('Per Ride')}</th><th>${t('Status')}</th><th>${t('Linked login')}</th><th></th></tr></thead>
      <tbody>${A.riders.map(r => `<tr><td><b>${esc(r.rider_code)}</b></td><td>${esc(r.name)}</td><td>${esc(r.phone || '—')}</td><td>${esc(r.vehicle_type)} ${esc(r.vehicle_no || '')}</td><td>${money(r.per_ride_rate)}</td>
        <td><span class="pill ${{ available: 'ok', on_delivery: 'warn', offline: 'gray', inactive: 'bad' }[r.status]}">${t(RSTATUSA[r.status])}</span></td>
        <td>${r.user_id ? `<span class="pill ok">${t('Linked')}</span>` : `<button class="btn sm ghost" data-link="${r.id}">${t('Link user')}</button>`}</td>
        <td class="row"><button class="btn sm ghost" data-redit="${r.id}">${t('Edit')}</button></td></tr>`).join('') || `<tr><td colspan="8" class="center muted">${t('No riders yet')}</td></tr>`}</tbody>`;
    $$('[data-redit]').forEach(b => b.onclick = () => this.riderModal(A.riders.find(r => r.id === +b.dataset.redit)));
    $$('[data-link]').forEach(b => b.onclick = () => this.linkModal(+b.dataset.link));
  },
  async linkModal(riderId) {
    const users = await q(sb.from('profiles').select('*').eq('role', 'delivery').eq('is_active', true));
    const free = users.filter(u => !A.riders.some(r => r.user_id === u.id));
    const w = Modal.open({
      title: t('Link Rider to login'), html: free.length ? `<div class="col">${free.map(u => `<button type="button" class="btn block" data-u="${u.id}">${esc(u.full_name)} (${esc(u.username)})</button>`).join('')}</div>` : `<div class="empty">${t('No free Delivery Staff accounts. Create one from Users & Roles first.')}</div>`
    });
    $$('[data-u]', w).forEach(b => b.onclick = () => safe(async () => { await q(sb.from('riders').update({ user_id: b.dataset.u }).eq('id', riderId)); Modal.close(w); toast(t('Linked')); refresh(); }));
  },
  riderModal(r) {
    const w = Modal.open({
      title: t(r ? 'Edit Rider' : 'Add Rider'), html: `<div class="form-grid">
      <label class="f">${t('Rider Name')}<input id="r-name" value="${esc(r?.name || '')}"></label>
      <label class="f">${t('Phone Number')}<input id="r-phone" value="${esc(r?.phone || '')}"></label>
      <label class="f">${t('Vehicle Type')}<select id="r-veh">${['Bike', 'Car', 'Bicycle'].map(v => `<option ${r?.vehicle_type === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label class="f">${t('Vehicle Number')}<input id="r-vno" value="${esc(r?.vehicle_no || '')}"></label>
      <label class="f">${t('Per Ride Rate (Rs.)')}<input id="r-rate" type="number" value="${r?.per_ride_rate ?? (num((A.settings.rider || {}).default_rate) || 100)}"></label></div>
      ${r ? `<div class="sm muted">${t('Rider ID')}: <b>${esc(r.rider_code)}</b> (${t('permanent')})</div>` : ''}
      <div class="row wrap">${r ? `<button class="btn danger" id="r-del">${t('Delete Rider')}</button>` : ''}<button class="btn primary grow" id="r-save">${t('Save')}</button></div>`
    });
    $('#r-save', w).onclick = ev => safe(async () => {
      const p = { name: $('#r-name', w).value.trim(), phone: $('#r-phone', w).value.trim(), vehicle_type: $('#r-veh', w).value, vehicle_no: $('#r-vno', w).value.trim(), per_ride_rate: num($('#r-rate', w).value) };
      if (!p.name) throw new Error(t('Enter rider name'));
      if (r) await q(sb.from('riders').update(p).eq('id', r.id)); else await q(sb.from('riders').insert({ ...p, status: 'offline' }));
      Modal.close(w); toast(t('Saved')); refresh();
    }, { busy: ev.currentTarget });
    if (r) $('#r-del', w).onclick = () => safe(async () => { if (!await confirmBox(t('Delete this rider?'), { danger: true })) return; await q(sb.from('riders').delete().eq('id', r.id)); Modal.close(w); toast(t('Deleted')); refresh(); });
  },
  paintIncent() {
    $('#in-tbl').innerHTML = `<thead><tr><th>${t('Rule')}</th><th>${t('Period')}</th><th>${t('Target rides')}</th><th class="num">${t('Bonus')}</th><th>${t('Active')}</th><th></th></tr></thead>
      <tbody>${A.incentives.map(i => `<tr><td>${esc(i.name)}</td><td>${t({ day: 'Per day', week: 'Per week', month: 'Per month', all: 'All time' }[i.period])}</td><td>${i.target}</td><td class="num">${money(i.bonus)}</td>
      <td><input type="checkbox" data-iav="${i.id}" ${i.is_active ? 'checked' : ''}></td><td><button class="btn sm danger" data-idel="${i.id}">${t('Delete')}</button></td></tr>`).join('') || `<tr><td colspan="6" class="center muted">${t('No incentive rules')}</td></tr>`}</tbody>`;
    $$('[data-iav]').forEach(cb => cb.onchange = () => safe(() => q(sb.from('rider_incentives').update({ is_active: cb.checked }).eq('id', cb.dataset.iav))));
    $$('[data-idel]').forEach(b => b.onclick = () => safe(async () => { await q(sb.from('rider_incentives').delete().eq('id', b.dataset.idel)); toast(t('Deleted')); refresh(); }));
  },
  incentModal() {
    const w = Modal.open({
      title: t('Add Incentive Rule'), html: `<div class="form-grid">
      <label class="f full">${t('Rule name')}<input id="i-name" placeholder="${t('e.g. 100 rides this month')}"></label>
      <label class="f">${t('Period')}<select id="i-period"><option value="day">${t('Per day')}</option><option value="week">${t('Per week')}</option><option value="month" selected>${t('Per month')}</option><option value="all">${t('All time')}</option></select></label>
      <label class="f">${t('Target rides')}<input id="i-target" type="number" value="100"></label>
      <label class="f">${t('Bonus (Rs.)')}<input id="i-bonus" type="number" value="2000"></label></div>
      <button class="btn primary lg" id="i-save">${t('Save')}</button>`
    });
    $('#i-save', w).onclick = ev => safe(async () => {
      const p = { name: $('#i-name', w).value.trim(), period: $('#i-period', w).value, target: num($('#i-target', w).value), bonus: num($('#i-bonus', w).value) };
      if (!p.name || !p.target) throw new Error(t('Fill all fields'));
      await q(sb.from('rider_incentives').insert(p)); Modal.close(w); toast(t('Saved')); refresh();
    }, { busy: ev.currentTarget });
  }
};
const RSTATUSA = { available: 'Available', on_delivery: 'On Delivery', offline: 'Offline', inactive: 'Inactive' };

/* ---------- USERS & ROLES ---------- */
VIEWS.users = {
  async render() {
    const users = await q(sb.from('profiles').select('*').order('created_at'));
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Users & Roles')}</h2></div>
      <div class="banner mb">${t('New staff create their own login from the POS login screen ("New staff — create account"). Activate them and set their role here.')}</div>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>${t('Name')}</th><th>${t('Username')}</th><th>${t('Role')}</th><th>${t('Active')}</th><th></th></tr></thead>
      <tbody>${users.map(u => `<tr><td>${esc(u.full_name)}</td><td>${esc(u.username)}</td>
        <td><select data-urole="${u.id}" ${u.role === 'super_admin' && u.id === Shell.profile.id ? 'disabled' : ''}>${Object.keys(ROLE_LABEL).map(r => `<option value="${r}" ${u.role === r ? 'selected' : ''}>${t(ROLE_LABEL[r])}</option>`).join('')}</select></td>
        <td><label class="row sm"><input type="checkbox" data-uactive="${u.id}" ${u.is_active ? 'checked' : ''} ${u.id === Shell.profile.id ? 'disabled' : ''}> ${t('Active')}</label></td>
        <td><button class="btn sm ghost" data-upass="${u.id}">${t('Set Password')}</button></td></tr>`).join('')}</tbody></table></div>`;
    $$('[data-urole]').forEach(s => s.onchange = () => safe(() => q(sb.from('profiles').update({ role: s.value }).eq('id', s.dataset.urole))));
    $$('[data-uactive]').forEach(cb => cb.onchange = () => safe(() => q(sb.from('profiles').update({ is_active: cb.checked }).eq('id', cb.dataset.uactive))));
    $$('[data-upass]').forEach(b => b.onclick = () => safe(async () => { const p = await askText(t('Set Password'), t('New password / PIN (min 6 chars)'), { type: 'password' }); if (!p) return; await rpc('admin_set_password', { p_user: b.dataset.upass, p_password: p }); toast(t('Password updated')); }));
  }
};

/* ---------- BUSINESS SETTINGS ---------- */
VIEWS.settings = {
  render() {
    $('#view').innerHTML = `<div class="view-head"><h2>${t('Business Settings')}</h2></div><div id="bs-body"></div>`;
    $('#bs-body').innerHTML = settingsFormHTML(A.settings, A.role === 'super_admin');
    $('#s-save').onclick = ev => safe(async () => { await saveSettingsForm(A.settings, A.role === 'super_admin'); A.settings = await loadSettings(); toast(t('Settings saved')); }, { busy: ev.currentTarget });
  }
};
