/* =====================================================================
   THE YOUNG MALANG — core.js  (shared by POS, Admin and Customer site)
   ===================================================================== */
const CFG = window.YM_CONFIG;
const BR = CFG.BRAND;
const CONFIGURED = !/YOUR-/.test(CFG.SUPABASE_URL + CFG.SUPABASE_ANON_KEY);
const sb = window.supabase.createClient(CONFIGURED ? CFG.SUPABASE_URL : 'https://placeholder.supabase.co', CONFIGURED ? CFG.SUPABASE_ANON_KEY : 'placeholder', {
  auth: { persistSession: true, autoRefreshToken: true },
  realtime: { params: { eventsPerSecond: 10 } }
});

/* ---------- tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => Number(v) || 0;
const money = n => `${BR.currency} ${Math.round(num(n)).toLocaleString('en-US')}`;
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }));
const debounce = (fn, ms = 300) => { let h; return (...a) => { clearTimeout(h); h = setTimeout(() => fn(...a), ms); }; };
const startOfDay = (d = new Date()) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const isoDate = d => { const x = new Date(d); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
const fmtTime = iso => iso ? new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—';
const fmtDT = iso => iso ? new Date(iso).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
const ago = iso => { const m = Math.max(0, Math.round((Date.now() - new Date(iso)) / 60000)); return m < 60 ? `${m}m` : `${Math.floor(m / 60)}h ${m % 60}m`; };
const normPhone = p => String(p || '').replace(/[^0-9+]/g, '');

/* ---------- language (English / اردو) ---------- */
let LANG = localStorage.getItem('ym_lang') || 'en';
const t = s => (LANG === 'ur' && window.UR && window.UR[s]) || s;
function setLang(l) {
  LANG = l; localStorage.setItem('ym_lang', l);
  document.documentElement.lang = l; document.documentElement.dir = l === 'ur' ? 'rtl' : 'ltr';
  document.body.classList.toggle('ur', l === 'ur');
  $$('[data-t]').forEach(el => { el.textContent = t(el.dataset.t); });
  $$('[data-tp]').forEach(el => { el.placeholder = t(el.dataset.tp); });
  $$('.lang-btn').forEach(b => { b.textContent = l === 'ur' ? 'English' : 'اردو'; });
  $$('select.theme-sel option').forEach(o => { o.textContent = t(o.dataset.en); });
}
const pick = (o, k = 'name') => (LANG === 'ur' && o[k + '_ur']) || o[k];

/* ---------- theme ---------- */
const THEMES = [['classic', 'Classic'], ['dark', 'Dark'], ['sunny', 'Sunny']];
function setTheme(x) {
  if (!THEMES.some(a => a[0] === x)) x = 'classic';
  document.documentElement.dataset.theme = x; localStorage.setItem('ym_theme', x);
  $$('select.theme-sel').forEach(s => { s.value = x; });
}
const themeSelect = id => `<select class="theme-sel" id="${id}" aria-label="Theme">${THEMES.map(([v, n]) => `<option value="${v}" data-en="${n}">${t(n)}</option>`).join('')}</select>`;

/* ---------- labels ---------- */
const SRC = { walkin: 'WALK-IN', dinein: 'DINE-IN', takeaway: 'TAKEAWAY', phone: 'PHONE', online: 'ONLINE', qr: 'QR' };
const FUL = { dinein: 'Dine-in', pickup: 'Pickup', delivery: 'Delivery' };
const STATUS = { pending: 'Pending', accepted: 'Accepted', preparing: 'Preparing', ready: 'Ready', served: 'Served', assigned: 'Assigned', picked_up: 'Picked Up', on_the_way: 'On the Way', delivered: 'Delivered', completed: 'Completed', cancelled: 'Cancelled', rejected: 'Rejected' };
const RSTATUS = { available: 'Available', on_delivery: 'On Delivery', offline: 'Offline', inactive: 'Inactive' };
const RDOT = { available: 'green', on_delivery: 'orange', offline: 'gray', inactive: 'red' };
const srcTag = s => `<span class="src ${s}">${t(SRC[s] || s)}</span>`;
const isOnlineSrc = s => s === 'online' || s === 'qr';
const stPill = s => {
  const cls = { pending: 'warn', accepted: 'info', preparing: 'warn', ready: 'ok', served: 'ok', assigned: 'info', picked_up: 'info', on_the_way: 'info', delivered: 'ok', completed: 'ok', cancelled: 'bad', rejected: 'bad' }[s] || '';
  return `<span class="pill ${cls}">${t(STATUS[s] || s)}</span>`;
};
const payPill = s => `<span class="pill ${{ paid: 'ok', partial: 'warn', unpaid: 'bad' }[s]}">${t({ paid: 'Paid', partial: 'Partial', unpaid: 'Unpaid' }[s])}</span>`;
const catEmoji = n => { n = (n || '').toLowerCase(); return /pizza/.test(n) ? '🍕' : /burger/.test(n) ? '🍔' : /fries/.test(n) ? '🍟' : /snack|wing|nugget/.test(n) ? '🍗' : /drink|juice|cola|water/.test(n) ? '🥤' : /deal|combo/.test(n) ? '🎁' : /dessert|cake|ice|brownie/.test(n) ? '🍰' : '🍽️'; };

/* ---------- toast / modal ---------- */
function toast(msg, kind = 'ok') {
  const root = $('#toast-root'); if (!root) return;
  const d = document.createElement('div'); d.className = `toast ${kind}`; d.textContent = msg; root.appendChild(d);
  setTimeout(() => d.remove(), kind === 'err' ? 6000 : 3200);
}
const Modal = {
  open({ title = '', html = '', wide = false, onClose, onMount }) {
    const w = document.createElement('div'); w.className = 'modal-wrap';
    w.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><div class="modal-h"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="Close">✕</button></div><div class="modal-b">${html}</div></div>`;
    w._onClose = onClose;
    w.addEventListener('mousedown', e => { w._down = e.target === w; });
    w.addEventListener('click', e => { if ((e.target === w && w._down) || e.target.closest('[data-close]')) Modal.close(w); });
    $('#modal-root').appendChild(w);
    onMount && onMount(w);
    return w;
  },
  close(w) { w = w || $$('.modal-wrap').pop(); if (!w) return; w.remove(); w._onClose && w._onClose(); },
  closeAll() { $$('.modal-wrap').forEach(w => Modal.close(w)); }
};
function confirmBox(msg, { ok = 'Confirm', danger = false } = {}) {
  return new Promise(res => {
    let done = false;
    const w = Modal.open({
      title: t('Please confirm'),
      html: `<p class="confirm-msg">${esc(msg)}</p><div class="row end"><button class="btn" data-close>${t('Cancel')}</button><button class="btn ${danger ? 'danger' : 'primary'}" id="cf-ok">${t(ok)}</button></div>`,
      onClose: () => { if (!done) res(false); }
    });
    $('#cf-ok', w).onclick = () => { done = true; res(true); Modal.close(w); };
  });
}
function askText(title, label, { value = '', type = 'text', ok = 'Save', textarea = false } = {}) {
  return new Promise(res => {
    let done = false;
    const w = Modal.open({
      title,
      html: `<label class="f">${esc(label)}${textarea ? `<textarea id="at-in">${esc(value)}</textarea>` : `<input id="at-in" type="${type}" value="${esc(value)}">`}</label><div class="row end"><button class="btn" data-close>${t('Cancel')}</button><button class="btn primary" id="at-ok">${t(ok)}</button></div>`,
      onClose: () => { if (!done) res(null); }
    });
    const inp = $('#at-in', w); setTimeout(() => inp.focus(), 50);
    const go = () => { done = true; res(inp.value.trim()); Modal.close(w); };
    $('#at-ok', w).onclick = go;
    if (!textarea) inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  });
}

/* ---------- server calls ---------- */
async function rpc(name, args) {
  const { data, error } = await sb.rpc(name, args);
  if (error) throw new Error(friendlyErr(error));
  return data;
}
function friendlyErr(e) {
  const m = (e && e.message) || String(e);
  if (/JWT|expired/i.test(m)) return t('Session expired — please log in again');
  if (/Failed to fetch|NetworkError/i.test(m)) return t('No internet connection');
  if (/duplicate key/i.test(m)) return t('This already exists');
  if (/violates row-level security/i.test(m)) return t('Not allowed');
  return m;
}
async function safe(fn, { busy } = {}) {
  if (busy) busy.disabled = true;
  try { return await fn(); }
  catch (e) { console.error(e); toast(friendlyErr(e), 'err'); }
  finally { if (busy) busy.disabled = false; }
}
async function q(promise) { const { data, error } = await promise; if (error) throw new Error(friendlyErr(error)); return data; }

/* ---------- sounds ---------- */
function beep() {
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    [880, 1175, 880].forEach((f, i) => {
      const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f; o.connect(g); g.connect(ac.destination);
      const s = ac.currentTime + i * 0.2; g.gain.setValueAtTime(0.2, s); g.gain.exponentialRampToValueAtTime(0.001, s + 0.18); o.start(s); o.stop(s + 0.19);
    });
  } catch (e) { /* audio blocked */ }
}

/* ---------- analog clock ---------- */
function mountClock(box, size = 52) {
  if (!box) return;
  const ticks = [...Array(12)].map((_, i) => `<line class="c-tick" x1="0" y1="-41" x2="0" y2="${i % 3 === 0 ? -34 : -37}" transform="rotate(${i * 30})"/>`).join('');
  box.innerHTML = `<div class="clock"><svg viewBox="-50 -50 100 100" width="${size}" height="${size}" role="img" aria-label="Clock"><circle r="47" class="c-face"/>${ticks}<line class="c-hand c-h" x1="0" y1="3" x2="0" y2="-22"/><line class="c-hand c-m" x1="0" y1="4" x2="0" y2="-32"/><line class="c-hand c-s" x1="0" y1="8" x2="0" y2="-36"/><circle r="3" class="c-pin"/></svg><div class="clock-digi"><b></b><span></span></div></div>`;
  const h = $('.c-h', box), m = $('.c-m', box), s = $('.c-s', box), tb = $('.clock-digi b', box), dt = $('.clock-digi span', box);
  const tick = () => {
    const d = new Date(), sec = d.getSeconds(), min = d.getMinutes() + sec / 60, hr = (d.getHours() % 12) + min / 60;
    h.setAttribute('transform', `rotate(${hr * 30})`); m.setAttribute('transform', `rotate(${min * 6})`); s.setAttribute('transform', `rotate(${sec * 6})`);
    tb.textContent = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    dt.textContent = d.toLocaleDateString(LANG === 'ur' ? 'ur-PK' : 'en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  };
  tick(); return setInterval(tick, 1000);
}

/* ---------- logo ---------- */
const logoHTML = (h = 78) => `<span class="logo-plate"><img src="${BR.logo}" alt="${esc(BR.name)}" style="height:${h}px" onerror="this.replaceWith(Object.assign(document.createElement('b'),{textContent:'${esc(BR.name)}'}))"></span>`;

/* ---------- Shell: login + session + top bar ---------- */
const Shell = {
  profile: null, cfg: null, clockTimer: null,
  init(cfg) {
    this.cfg = cfg;
    setTheme(localStorage.getItem('ym_theme') || 'classic'); setLang(LANG);
    this.drawLogin(); this.drawTopbar();
    this.boot();
  },
  drawLogin() {
    $('#login').innerHTML = `<form class="login-card" id="lg-form" autocomplete="on">
      <div class="login-brand">${logoHTML(120)}<p>${esc(BR.tagline)} · ${esc(BR.address)}</p></div>
      <h2 class="login-title">${t(this.cfg.loginTitle)}</h2>
      <div class="login-clock" id="login-clock"></div>
      ${CONFIGURED ? '' : `<div class="setup-warn">Supabase is not connected yet. Open <b>js/config.js</b> and paste your Project URL and anon key.</div>`}
      <label class="f">${t('Username / Email')}<input id="lg-user" autocomplete="username" autocapitalize="none" required></label>
      <label class="f">${t('Password / PIN')}<div class="pw"><input id="lg-pass" type="password" autocomplete="current-password" required><button type="button" class="icon-btn" id="lg-eye" aria-label="Show password">👁</button></div></label>
      <div class="err" id="lg-err" role="alert"></div>
      <button class="btn primary lg" id="lg-btn" type="submit">${t('Login')}</button>
      ${this.cfg.allowSignup ? `<button type="button" class="btn ghost" id="lg-signup">${t('New staff — create account')}</button>` : ''}
      <div class="login-tools"><button type="button" class="btn ghost sm lang-btn"></button>${themeSelect('lg-theme')}</div>
      <p class="login-foot">${BR.phones.join(' · ')}</p></form>`;
    setLang(LANG); setTheme(localStorage.getItem('ym_theme') || 'classic');
    mountClock($('#login-clock'), 64);
    $('#lg-eye').onclick = () => { const i = $('#lg-pass'); i.type = i.type === 'password' ? 'text' : 'password'; };
    $('#lg-form').onsubmit = e => { e.preventDefault(); this.doLogin(); };
    $('#lg-theme').onchange = e => setTheme(e.target.value);
    $('#login .lang-btn').onclick = () => this.toggleLang();
    if (this.cfg.allowSignup) $('#lg-signup').onclick = () => this.signupFlow();
  },
  drawTopbar() {
    $('#topbar').innerHTML = `<button class="icon-btn only-mobile" id="btn-menu" aria-label="Menu">☰</button>
      <div class="tb-title" id="tb-title"></div>
      <div class="tb-right">
        <span id="tb-live" class="live off">● ${t('Live')}</span>
        <div class="tb-clock" id="tb-clock"></div>
        <button class="btn ghost sm lang-btn" id="btn-lang"></button>
        ${themeSelect('sel-theme')}
        <div class="tb-user"><span class="avatar" id="tb-av">?</span><div><b id="tb-name"></b><small id="tb-role"></small></div></div>
      </div>`;
    $('#btn-lang').onclick = () => this.toggleLang();
    $('#sel-theme').onchange = e => setTheme(e.target.value);
    $('#btn-menu').onclick = () => $('#app').classList.toggle('menu-open');
    setLang(LANG); setTheme(localStorage.getItem('ym_theme') || 'classic');
  },
  toggleLang() {
    setLang(LANG === 'ur' ? 'en' : 'ur');
    if (!$('#login').classList.contains('hidden')) this.drawLogin();
    else { this.drawTopbar(); this.fillUser(); this.cfg.onLang && this.cfg.onLang(); }
  },
  showLogin() { $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); setTimeout(() => $('#lg-user') && $('#lg-user').focus(), 50); },
  async boot() {
    if (!CONFIGURED) return this.showLogin();
    const { data: { session } } = await sb.auth.getSession();
    if (session && await this.enter(session)) return;
    this.showLogin();
  },
  async doLogin() {
    const u = $('#lg-user').value.trim(), p = $('#lg-pass').value;
    const err = $('#lg-err'), btn = $('#lg-btn'); err.textContent = '';
    if (!CONFIGURED) { err.textContent = 'Supabase is not connected — edit js/config.js'; return; }
    btn.disabled = true;
    const email = u.includes('@') ? u : `${u.toLowerCase().replace(/\s+/g, '')}@${CFG.USERNAME_DOMAIN}`;
    const { data, error } = await sb.auth.signInWithPassword({ email, password: p });
    if (error) { err.textContent = t('Wrong username or password'); btn.disabled = false; return; }
    const ok = await this.enter(data.session);
    if (!ok) btn.disabled = false;
  },
  async enter(session) {
    const { data: prof } = await sb.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    const fail = async msg => { await sb.auth.signOut(); this.showLogin(); const e = $('#lg-err'); if (e) e.textContent = msg; return false; };
    if (!prof) return fail(t('Account not found'));
    if (!prof.is_active) return fail(t('Your account is not active. Ask the admin.'));
    if (!this.cfg.roles.includes(prof.role)) return fail(t('You do not have access to this page'));
    this.profile = prof;
    $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
    this.fillUser();
    await this.cfg.onReady(prof);
    return true;
  },
  fillUser() {
    const p = this.profile; if (!p) return;
    $('#tb-name').textContent = p.full_name || p.username;
    $('#tb-role').textContent = t(ROLE_LABEL[p.role] || p.role);
    $('#tb-av').textContent = (p.full_name || p.username || '?').trim().charAt(0).toUpperCase();
    if (this.clockTimer) clearInterval(this.clockTimer);
    this.clockTimer = mountClock($('#tb-clock'), 46);
  },
  title(s) { const el = $('#tb-title'); if (el) el.textContent = s; },
  signupFlow() {
    const w = Modal.open({
      title: t('Create staff account'), html: `<div class="form-grid">
      <label class="f full">${t('Full Name')}<input id="su-name" required></label>
      <label class="f full">${t('Username')} (${t('no spaces')})<input id="su-user" autocapitalize="none" required></label>
      <label class="f full">${t('Password / PIN')} (${t('min 6 characters')})<input id="su-pass" type="password" required></label></div>
      <div class="banner">${t('Your account will be inactive until an admin approves it and sets your role, except the very first account — which becomes Super Admin automatically.')}</div>
      <div class="err" id="su-err"></div><button class="btn primary lg" id="su-go">${t('Create account')}</button>`
    });
    $('#su-go', w).onclick = () => safe(async () => {
      const name = $('#su-name', w).value.trim(), user = $('#su-user', w).value.trim().toLowerCase().replace(/\s+/g, ''), pass = $('#su-pass', w).value;
      if (!name || !user || pass.length < 6) { $('#su-err', w).textContent = t('Fill all fields — password needs 6+ characters'); return; }
      const email = `${user}@${CFG.USERNAME_DOMAIN}`;
      const { data, error } = await sb.auth.signUp({ email, password: pass, options: { data: { full_name: name } } });
      if (error) { $('#su-err', w).textContent = /already/i.test(error.message) ? t('Username already taken') : error.message; return; }
      Modal.close(w);
      if (data.session) { const ok = await this.enter(data.session); if (ok) return; }
      toast(t('Account created — ask an admin to activate it, then log in'), 'ok');
    }, { busy: $('#su-go', w) });
  },
  async logout() {
    try { this.cfg.onLogout && await this.cfg.onLogout(); } catch (e) { /* ignore */ }
    await sb.auth.signOut(); location.reload();
  }
};
const ROLE_LABEL = { super_admin: 'Super Admin', manager: 'Manager', cashier: 'Cashier', waiter: 'Waiter', kitchen: 'Kitchen Staff', delivery: 'Delivery Staff' };

/* ---------- realtime ---------- */
const Live = {
  start(tables, cb) {
    this.stop();
    this.ch = sb.channel('ym-live-' + Math.random().toString(36).slice(2));
    tables.forEach(tb => this.ch.on('postgres_changes', { event: '*', schema: 'public', table: tb }, p => cb(tb, p)));
    this.ch.subscribe(st => { const el = $('#tb-live'); if (el) el.classList.toggle('off', st !== 'SUBSCRIBED'); });
    // safety net: if the realtime connection drops, still refresh every 30 seconds
    this.poll = setInterval(() => cb('poll', null), 30000);
  },
  stop() { if (this.ch) sb.removeChannel(this.ch); clearInterval(this.poll); }
};

/* ---------- item picker (size / add-ons / notes) shared by POS + website ---------- */
const NOTE_CHIPS = ['No Onion', 'Extra Spicy', 'Less Spicy', 'No Sauce', 'Extra Sauce', 'Well Done'];
function openItemPicker({ product, variants, addons, initial, onAdd }) {
  const pv = variants.filter(v => v.product_id === product.id).sort((a, b) => a.sort - b.sort || a.price - b.price);
  const pa = addons.filter(a => a.is_active !== false && (a.category_id == null || a.category_id === product.category_id));
  const st = { vid: initial?.variant_id ?? (pv[0] ? pv[0].id : null), add: new Set((initial?.addons || []).map(a => a.id)), qty: initial?.qty || 1, note: initial?.note || '' };
  const calc = () => {
    const v = pv.find(x => x.id === st.vid); const base = v ? num(v.price) : num(product.price);
    const ad = pa.filter(a => st.add.has(a.id)); return { v, ad, unit: base + ad.reduce((s, a) => s + num(a.price), 0) };
  };
  const body = () => {
    const c = calc();
    return `<div class="row"><b class="grow" style="font-size:18px">${esc(pick(product))}</b><span class="display" style="font-size:20px">${money(c.unit)}</span></div>
      ${pv.length ? `<div><div class="muted b sm mb">${t('Size')}</div><div class="chips">${pv.map(v => `<button type="button" class="chip ${v.id === st.vid ? 'on' : ''}" data-v="${v.id}">${esc(pick(v))} · ${money(v.price)}</button>`).join('')}</div></div>` : ''}
      ${pa.length ? `<div><div class="muted b sm mb">${t('Add-ons')}</div><div class="chips">${pa.map(a => `<button type="button" class="chip ${st.add.has(a.id) ? 'on' : ''}" data-a="${a.id}">+ ${esc(pick(a))} · ${money(a.price)}</button>`).join('')}</div></div>` : ''}
      <div><div class="muted b sm mb">${t('Special Instructions')}</div>
        <div class="chips mb">${NOTE_CHIPS.map(n => `<button type="button" class="chip" data-n="${esc(n)}">${t(n)}</button>`).join('')}</div>
        <input id="ip-note" value="${esc(st.note)}" placeholder="${t('e.g. No onion, extra spicy')}" maxlength="120"></div>
      <div class="row between"><div class="qty"><button type="button" data-q="-1">−</button><span>${st.qty}</span><button type="button" data-q="1">+</button></div>
      <button type="button" class="btn primary lg grow" id="ip-add">${t(initial ? 'Update Item' : 'ADD TO ORDER')} · ${money(c.unit * st.qty)}</button></div>`;
  };
  const w = Modal.open({ title: pick(product), html: `<div class="col" id="ip-body"></div>` });
  const paint = () => { $('#ip-body', w).innerHTML = body(); };
  paint();
  w.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.v) { st.vid = +b.dataset.v; st.note = $('#ip-note', w).value; paint(); }
    else if (b.dataset.a) { const id = +b.dataset.a; st.add.has(id) ? st.add.delete(id) : st.add.add(id); st.note = $('#ip-note', w).value; paint(); }
    else if (b.dataset.n) { const i = $('#ip-note', w); const n = t(b.dataset.n); i.value = i.value ? `${i.value}, ${n}` : n; i.focus(); }
    else if (b.dataset.q) { st.qty = Math.max(1, Math.min(50, st.qty + +b.dataset.q)); st.note = $('#ip-note', w).value; paint(); }
    else if (b.id === 'ip-add') {
      const c = calc(); st.note = $('#ip-note', w).value.trim();
      onAdd({ product_id: product.id, name: product.name, name_ur: product.name_ur, variant_id: c.v ? c.v.id : null, variant_name: c.v ? c.v.name : null,
        base: c.v ? num(c.v.price) : num(product.price), addons: c.ad.map(a => ({ id: a.id, name: a.name, price: num(a.price) })), qty: st.qty, note: st.note });
      Modal.close(w);
    }
  });
  return w;
}

/* ---------- receipts ---------- */
const Receipt = {
  // who served this order, for the "Served By" line — dine-in/QR shows the waiter,
  // delivery shows the rider (with Rider ID), manual/takeaway shows the cashier who created it.
  servedBy(o) {
    if (o.fulfillment === 'dinein' || o.source === 'qr') {
      // dine-in / QR: show the waiter if one is assigned — otherwise show nothing (no empty field)
      return o.waiter ? { label: 'Served By', name: o.waiter.full_name, id: o.waiter.staff_id } : null;
    }
    if (o.fulfillment === 'delivery') {
      const d = (o.deliveries || []).slice().sort((a, b) => b.id - a.id)[0];
      return (d && d.riders) ? { label: 'Rider', name: d.riders.name, id: d.riders.rider_code } : null;
    }
    // takeaway / walk-in / phone: show the cashier who created the order
    return o.creator ? { label: 'Served By', name: o.creator.full_name, id: o.creator.staff_id } : null;
  },
  body(o, S = {}) {
    const r = S.restaurant || {}; const phones = (r.phones || BR.phones).join(' / ');
    const lines = (o.order_items || []).map(i => `<tr><td>${i.qty} × ${esc(i.name)}${i.variant ? ` (${esc(i.variant)})` : ''}${(i.addons || []).length ? `<br><small>+ ${i.addons.map(a => esc(a.name)).join(', ')}</small>` : ''}${i.note ? `<br><small>“${esc(i.note)}”</small>` : ''}</td><td class="r">${money(i.line_total)}</td></tr>`).join('');
    const row = (l, v) => `<tr><td>${l}</td><td class="r">${v}</td></tr>`;
    const sb = this.servedBy(o);
    return `<div class="rcpt-box"><img src="${BR.logo}" alt=""><h4>${esc(r.name || BR.name)}</h4>
      <div class="c">${esc(r.address || BR.address)}<br>${esc(phones)}${r.ntn ? `<br>NTN: ${esc(r.ntn)}` : ''}</div><hr>
      <table>${row('Order No', `<b>${esc(o.order_no)}</b>`)}${row('Receipt No', esc(o.receipt_no || '—'))}${row('Date', fmtDT(o.created_at))}${row('Type', `${SRC[o.source] || o.source} / ${FUL[o.fulfillment] || o.fulfillment}`)}
      ${o.tbl ? row('Table', esc(o.tbl.code)) : ''}${o.customer_name ? row('Customer', esc(o.customer_name)) : ''}${o.phone ? row('Phone', esc(o.phone)) : ''}
      ${o.fulfillment === 'delivery' && o.address ? row('Address', esc(o.address)) : ''}
      ${sb ? row(sb.label, esc(sb.name || '') + (sb.id ? ` (${esc(sb.id)})` : '')) : ''}</table><hr>
      <table>${lines}</table><hr>
      <table>${row('Subtotal', money(o.subtotal))}${num(o.discount) ? row('Discount', '− ' + money(o.discount)) : ''}${num(o.delivery_fee) ? row('Delivery', money(o.delivery_fee)) : ''}
      ${num(o.tax) ? row('Tax', money(o.tax)) : ''}${num(o.service_charge) ? row('Service charge', money(o.service_charge)) : ''}
      <tr class="t"><td>TOTAL</td><td class="r">${money(o.total)}</td></tr>
      ${row('Payment', esc(o.payment_method || '—'))}${row('Status', (o.payment_status || '').toUpperCase())}
      ${num(o.paid_amount) && o.payment_status !== 'paid' ? row('Paid', money(o.paid_amount)) + row('Remaining', money(num(o.total) - num(o.paid_amount))) : ''}</table><hr>
      <div class="c">${esc(r.receipt_footer || 'Thank you!')}</div></div>`;
  },
  SIZES: { '58': { w: '58mm', max: '210px', font: '11px' }, '80': { w: '80mm', max: '300px', font: '12.5px' }, a4: { w: '210mm', max: '640px', font: '14px' } },
  doc(o, S, autoPrint, size = '80') {
    const sz = this.SIZES[size] || this.SIZES['80'];
    return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(o.order_no)}</title><style>
      body{margin:0;padding:${size === 'a4' ? '24px' : '8px'};font-family:'Courier New',monospace;font-size:${sz.font};color:#000;background:#fff}
      .rcpt-box{max-width:${sz.max};margin:0 auto}.rcpt-box img{height:64px;display:block;margin:0 auto 4px}h4{margin:0;text-align:center;font-size:15px}
      table{width:100%;border-collapse:collapse}td{padding:2px 0;vertical-align:top}td.r{text-align:right}.c{text-align:center}hr{border:0;border-top:1px dashed #000;margin:6px 0}.t td{font-weight:800;font-size:14px}
      @page{size:${size === 'a4' ? 'A4' : sz.w + ' auto'};margin:${size === 'a4' ? '14mm' : '3mm'}}</style></head><body>${this.body(o, S)}${autoPrint ? '<script>window.onload=function(){setTimeout(function(){window.print()},300)}<\/script>' : ''}</body></html>`;
  },
  log(o, method) { rpc('log_receipt_print', { p_order: o.id, p_method: method }).catch(() => {}); },
  print(o, S, size = '80') {
    const w = window.open('', '_blank', 'width=420,height=640'); if (!w) return toast(t('Allow pop-ups to print'), 'err');
    w.document.write(this.doc(o, S, true, size)); w.document.close(); this.log(o, size === 'a4' ? 'A4' : size + 'mm');
  },
  download(o, S) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([this.doc(o, S, false, '80')], { type: 'text/html' })); a.download = `${o.receipt_no || o.order_no}.html`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000); this.log(o, 'digital');
  }
};

/* ---------- CSV / print helpers ---------- */
function downloadCSV(name, cols, rows) {
  const qt = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = '\ufeff' + [cols.map(c => qt(c.label)).join(','), ...rows.map(r => cols.map(c => qt(typeof c.get === 'function' ? c.get(r) : r[c.key])).join(','))].join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = `${name}-${isoDate(new Date())}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
function printHTML(title, html) {
  const w = window.open('', '_blank'); if (!w) return toast(t('Allow pop-ups to print'), 'err');
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{font-family:Arial,sans-serif;padding:20px;color:#000}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:5px 8px;text-align:left;font-size:13px}th{background:#eee}h2{margin:0 0 4px}.r{text-align:right}</style></head><body><h2>${esc(BR.name)}</h2><div>${esc(title)} — ${new Date().toLocaleString('en-GB')}</div><br>${html}<script>window.onload=function(){window.print()}<\/script></body></html>`);
  w.document.close();
}

/* ---------- settings form (used by POS Settings and Admin Settings) ---------- */
async function loadSettings() {
  const rows = await q(sb.from('settings').select('*')); const S = {};
  rows.forEach(r => { S[r.key] = r.value; }); return S;
}
async function saveSetting(key, value) {
  await q(sb.from('settings').upsert({ key, value, updated_at: new Date().toISOString() }));
}
function settingsFormHTML(S, canPerm) {
  const r = S.restaurant || {}, c = S.charges || {}, p = S.permissions || {}, o = S.online || {}, k = S.kitchen || {}, rd = S.rider || {};
  const f = (id, label, val, type = 'text') => `<label class="f">${t(label)}<input id="${id}" type="${type}" value="${esc(val ?? '')}"></label>`;
  return `<div class="col">
    <div class="card"><h3>${t('Restaurant & Receipt')}</h3><div class="form-grid">
      ${f('s-name', 'Restaurant name', r.name || BR.name)}${f('s-tag', 'Tagline', r.tagline || BR.tagline)}
      ${f('s-ph', 'Phone numbers (comma separated)', (r.phones || BR.phones).join(', '))}${f('s-addr', 'Address', r.address || BR.address)}
      ${f('s-ntn', 'NTN (Tax Number)', r.ntn || '')}
      <label class="f full">${t('Receipt footer')}<input id="s-foot" value="${esc(r.receipt_footer || '')}"></label></div></div>
    <div class="card"><h3>${t('Charges')}</h3><div class="form-grid">
      ${f('s-del', 'Delivery charges (Rs.)', c.delivery_fee ?? 0, 'number')}${f('s-free', 'Free delivery above (Rs., 0 = never)', c.free_delivery_above ?? 0, 'number')}
      ${f('s-tax', 'Tax %', c.tax_pct ?? 0, 'number')}${f('s-svc', 'Dine-in service charge %', c.service_charge_pct ?? 0, 'number')}
      ${f('s-min', 'Minimum online order (Rs.)', c.min_online_order ?? 0, 'number')}</div></div>
    <div class="card"><h3>${t('Payment Methods')}</h3><label class="f">${t('One per line')}<textarea id="s-pm">${esc((S.payment_methods || ['Cash', 'Card', 'Online Payment']).join('\n'))}</textarea></label></div>
    ${canPerm ? `<div class="card"><h3>${t('Permissions')}</h3><div class="form-grid">
      ${f('s-disc', 'Max discount for Cashier (%)', p.cashier_max_discount_pct ?? 0, 'number')}
      <label class="f">${t('Cashier can cancel orders')}<select id="s-canc"><option value="0" ${!p.cashier_can_cancel ? 'selected' : ''}>${t('No')}</option><option value="1" ${p.cashier_can_cancel ? 'selected' : ''}>${t('Yes (new/accepted only)')}</option></select></label>
      ${f('s-rate', 'Default rider rate per delivery (Rs.)', rd.default_rate ?? 100, 'number')}</div></div>` : ''}
    <div class="card"><h3>${t('Kitchen & Online')}</h3><div class="form-grid">
      <label class="f">${t('Kitchen alert sound')}<select id="s-ksnd"><option value="1" ${k.sound !== false ? 'selected' : ''}>${t('On')}</option><option value="0" ${k.sound === false ? 'selected' : ''}>${t('Off')}</option></select></label>
      <label class="f">${t('Website / QR ordering')}<select id="s-acc"><option value="1" ${o.accepting_orders !== false ? 'selected' : ''}>${t('Accepting orders')}</option><option value="0" ${o.accepting_orders === false ? 'selected' : ''}>${t('Paused')}</option></select></label></div></div>
    <button class="btn primary lg" id="s-save">${t('Save settings')}</button></div>`;
}
async function saveSettingsForm(S, canPerm) {
  const v = id => $(id).value;
  await saveSetting('restaurant', { name: v('#s-name'), tagline: v('#s-tag'), phones: v('#s-ph').split(',').map(x => x.trim()).filter(Boolean), address: v('#s-addr'), ntn: v('#s-ntn'), receipt_footer: v('#s-foot') });
  await saveSetting('charges', { delivery_fee: num(v('#s-del')), free_delivery_above: num(v('#s-free')), tax_pct: num(v('#s-tax')), service_charge_pct: num(v('#s-svc')), min_online_order: num(v('#s-min')) });
  await saveSetting('payment_methods', v('#s-pm').split('\n').map(x => x.trim()).filter(Boolean));
  if (canPerm) {
    await saveSetting('permissions', { cashier_max_discount_pct: num(v('#s-disc')), cashier_can_cancel: v('#s-canc') === '1' });
    await saveSetting('rider', { default_rate: num(v('#s-rate')) });
  }
  await saveSetting('kitchen', { sound: v('#s-ksnd') === '1' });
  await saveSetting('online', { accepting_orders: v('#s-acc') === '1' });
}
